import re
import csv
# import pandas as pd

with open('output.csv', 'rt',  encoding='UTF-8') as inp:
    read = csv.reader(inp)

    headerList=['Time', 'Type', 'DevAddr', 'DevEUI', 'FCnt', 'RJcount1', 'Invalid']

    f=open('filtered_packets.csv', 'w')
    writer=csv.writer(f)
    writer.writerow(headerList)

    for row in read:
        li=row[1].split('{')
        packetDetails=[]

        strStart=row[1].index("\'Time\': ")+8
        strEnd=strStart+row[1][strStart:len(row[1])].find(",")
        # packetDetails="Time: "+row[1][strStart:strEnd]
        packetDetails.append(row[1][strStart:strEnd])

        strStart=row[1].index("\'MTypeText\': ")+13
        strEnd=strStart+row[1][strStart:len(row[1])].find(",")
        # packetDetails+=", Type: "+row[1][strStart:strEnd]
        packetDetails.append(row[1][strStart:strEnd])

        if "DevAddr" in row[1]:
            strStart=row[1].index("\'DevAddr\': ")+11
            strEnd=strStart+row[1][strStart:len(row[1])].find(",")
            packetDetails.append(row[1][strStart:strEnd])
        else: packetDetails.append('')

        # if "Join-Accept" in row[1]:
        #     if "DevAddr" in row[1]:
        #         strStart=row[1].index("\'DevAddr\'")+11
        #         strEnd=strStart+row[1][strStart:len(row[1])].find(",")
        #         print(row[1][strStart:strEnd])

        if "DevEUI" in row[1]:
            strStart=row[1].index("\'DevEUI\': ")+10
            strEnd=strStart+row[1][strStart:len(row[1])].find(",")
            # packetDetails+=", DevEUI: "+row[1][strStart:strEnd]
            packetDetails.append(row[1][strStart:strEnd])
        else: packetDetails.append('')

        if "FCnt" in row[1]:
            strStart=row[1].index("\'FCnt\': ")+8
            strEnd=strStart+row[1][strStart:len(row[1])].find(",")
            # packetDetails+=", FCnt: "+row[1][strStart:strEnd]
            packetDetails.append(row[1][strStart:strEnd])
        else: packetDetails.append('')

        if "RJcount1" in row[1]:
            strStart=row[1].index("\'RJcount1\': ")+10
            strEnd=strStart+row[1][strStart:len(row[1])].find("}")
            # packetDetails+=", RJcount1: "+row[1][strStart:strEnd]
            packetDetails.append(row[1][strStart:strEnd])
        else: packetDetails.append('')

        if "Invalid" in row[1]:
            strStart=row[1].index("\'ParseMessage\': ")+16
            strEnd=strStart+row[1][strStart:len(row[1])].find(",")
            # packetDetails+=", Invalid: "+row[1][strStart:strEnd]
            packetDetails.append(row[1][strStart:strEnd])
        else: packetDetails.append('')

        # print(packetDetails)
        # print('\n')

        writer=csv.writer(f)
        writer.writerow(packetDetails)
