# FLoRa Framework v2.0

#
# LoRaWAN-v1.1 version
#
from lora.crypto import loramac_decrypt
from cryptography.hazmat.primitives import cmac
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.ciphers import algorithms
import sys, binascii
import struct

# local imports
import flora_parse_packet

# TODO:
# - Implement MIC calc for LoRaWAN 1.1 Net Server (Up/Dw msg's)
# - MIC and crypto for LoRaWAN 1.1 implementations
# - Calc Session keys for LoRaWAN 1.1

# Packets type
JOIN_REQUEST = "000"
JOIN_ACCEPT = "001"
REJOIN_REQUEST = "110"
UP_MSG_NCON = "010"
DW_MSG_NCON = "011"
UP_MSG_CON = "100"
DW_MSG_CON = "101"
PROPIERATY = "111"

# keys calculation for different (OTTA) messages / implementations
def calculate_keys(jr_packet, ja_packet, akey):
    # akey incompleted (32 bytes)
    akey = "0" * (32 - len(akey)) + akey

    # 
    # Spec: LoRaWAN 1.1
    # 
    # LoRaWAN 1.0:
    # NwkSKey = aes128_encrypt(AppKey, 0x01 | JoinNonce | NetID | DevNonce | pad16)
    # AppSKey = aes128_encrypt(AppKey, 0x02 | JoinNonce | NetID | DevNonce | pad16)
    # Size: JoinNonce (3) + NetID (3) + DevNonce (2) + 0x00 * 7 (padding)
    #
    JoinNonce = ja_packet["PHYPayload"]["JoinAccept"]["JoinNonce"]
    NetID = ja_packet["PHYPayload"]["JoinAccept"]["Home_NetID"]
    DevNonce = jr_packet["PHYPayload"]["JoinRequest"]["DevNonce"]

    cipher = AES.new(bytes.fromhex(akey), AES.MODE_ECB)
    data = bytes.fromhex(JoinNonce + NetID + DevNonce) + (b'\x00' * 7)
    NwkSKey = cipher.encrypt(b'\x01' + data)
    AppSKey = cipher.encrypt(b'\x02' + data)
    return "NwkSKey: %s\nAppSKey: %s" % (binascii.hexlify(NwkSKey).decode(), 
        binascii.hexlify(AppSKey).decode())
     
    # TODO: Implement "calculate_keys" for LoRaWAN 1.1
    # 
    # Spec: LoRaWAN 1.1
    # 
    # LoRaWAN 1.1:
    # For OTA devices two specific lifetime keys are derived from the NwkKey root key:
    # - JSIntKey is used to MIC Rejoin-Request type 1 messages and Join-Accept answers
    # - JSEncKey is used to encrypt the Join-Accept triggered by a Rejoin-Request
    #
    # JSIntKey = aes128_encrypt(NwkKey, 0x06 | DevEUI | pad 16 )
    # JSEncKey = aes128_encrypt(NwkKey, 0x05 | DevEUI | pad 16 )

from Crypto.Cipher import AES
def packet_encrypt(packet, akey):

    # parsing the packet
    MHDR = packet["RAWPacket"][:2]
    # MHDR (packet type)
    ptype = "{0:08b}".format(int(MHDR, 16))[:3]

    # akey incompleted (32 bytes)
    akey = "0" * (32 - len(akey)) + akey

    # 
    # Spec: LoRaWAN 1.1
    # 
    # The Join-Accept message is encrypted as follows:
    # aes128_decrypt(NwkKey or JSEncKey, JoinNonce | NetID | DevAddr | DLSettings | 
    #   RxDelay | CFList | MIC).
    #
    # if Join-Accept
    if ptype == JOIN_ACCEPT:
        cipher = AES.new(bytes.fromhex(akey), AES.MODE_ECB)
        join_pkt = bytes.fromhex(packet["RAWPacket"][2:])
        return MHDR + binascii.hexlify(cipher.decrypt(join_pkt)).decode()
    
    # TODO: UP/DW packet encryption should be implemented
    
# decrypt PHYPayload messages
def packet_decrypt(packet, akey): 

    # parsing the packet
    MHDR = packet["RAWPacket"][:2]
    # MHDR (packet type)
    ptype = "{0:08b}".format(int(MHDR, 16))[:3]

    # akey incompleted (32 bytes)
    akey = "0" * (32 - len(akey)) + akey
    
    # 
    # Spec: LoRaWAN 1.1
    # 
    # The Join-Accept message is encrypted as follows:
    # aes128_decrypt(NwkKey or JSEncKey, JoinNonce | NetID | DevAddr | DLSettings | 
    #   RxDelay | CFList | MIC).
    #
    # if Join-Accept
    if ptype == JOIN_ACCEPT:
        cipher = AES.new(bytes.fromhex(akey), AES.MODE_ECB)
        encrypted_join_pkt = bytes.fromhex(packet["RAWPacket"][2:])
        return MHDR + binascii.hexlify(cipher.encrypt(encrypted_join_pkt)).decode()

    # 
    # Spec: LoRaWAN 1.1
    # 
    # The direction field (Dir) is 0 for uplink fgames and 1 for downlink frames.
    # The blocks Ai are encrypted to get a sequence S of blocks Si:
    #   Si = aes128_encrypt(K, Ai) for i = 1..k
    #   S = S1|S2|..|Sk
    # 
    # Encryption and decryption of the payload is done by truncating
    #   (pld | pad16) xor S
    # to the first len(pld) octets.
    #
    # if DW/UP messages:
    elif ptype == UP_MSG_CON or ptype == DW_MSG_CON or ptype == UP_MSG_NCON or ptype == DW_MSG_NCON:

        # direction UP = 0 ; DW = 1
        if ptype == DW_MSG_CON or ptype == DW_MSG_NCON: 
            direction = 1
        else:
            direction = 0

        # packet info
        dev_addr = packet["PHYPayload"]["MACPayload"]["FHDR"]["DevAddr"]
        counter = packet["PHYPayload"]["MACPayload"]["FHDR"]["FCnt"]
        payload = packet["PHYPayload"]["MACPayload"]["FRMPayload"]
        try: 
            t = loramac_decrypt(payload, int(counter, 16), akey, dev_addr, direction)
            return bytes(t).hex()
        except:
            return ""

    # JOIN_REQUEST OR REJOIN_REQUEST
    else:
        return ""

# Check MIC (parsed_packet, network_key) # parsed packet structure
def packet_check_mic(packet, nkey):
    mic = packet_calculate_mic(packet, nkey) 

    # MIC check
    if mic != "" and mic != "Error":
        if packet["PHYPayload"]["MIC"].lower() == mic.lower(): 
            return "OK"
        else: 
            return "Fail"
    else:
        return mic

# calculate MIC (parsed_packet, network_key)
def packet_calculate_mic(packet, nkey):
    dir_arg = ""
    ptype = packet["PHYPayload"]["MHDR"]["MType"]

    # nkey incompleted (32 bytes)
    nkey = "0" * (32 - len(nkey)) + nkey

    #
    # Spec: LoRaWAN 1.1
    #
    # cmac = aes128_cmac(NwkKey, MHDR | JoinEUI | DevEUI | DevNonce)
    # MIC = cmac[0..3]
    #
    # if Join-request
    if ptype == JOIN_REQUEST: 
        MHDR = packet["RAWPacket"][:2]
        JoinEUI = packet["PHYPayload"]["JoinRequest"]["JoinEUI"]
        DevEUI = packet["PHYPayload"]["JoinRequest"]["DevEUI"]
        DevNonce = packet["PHYPayload"]["JoinRequest"]["DevNonce"]

        cmacF = cmac.CMAC(algorithms.AES(bytes.fromhex(nkey)), backend=default_backend())
        data = bytes.fromhex(MHDR + JoinEUI + DevEUI + DevNonce)
        cmacF.update(data)
        return binascii.hexlify(cmacF.finalize()[:4]).decode()

    # TODO: Implement the LoRaWAN 1.1 Net Server 
    #
    # Spec: LoRaWAN 1.1
    #
    # if the OptNeg bit is not set (LoRaWAN 1.0):
    # cmac = aes128_cmac(NwkKey, MHDR | JoinNonce | NetID | DevAddr | DLSettings 
    #    | RxDelay | CFList )
    # MIC = cmac[0..3]
    # 
    # if the OptNeg is seta (LoRaWAN 1.1):
    # cmac = aes128_cmac(JSIntKey,
    #       JoinReqType | JoinEUI | DevNonce | MHDR | JoinNonce | NetID | DevAddr |
    #       DLSettings | RxDelay | CFList )
    # MIC = cmac[0..3]
    #
    # if Join-accept
    elif ptype == JOIN_ACCEPT: 
        MHDR = packet["RAWPacket"][:2]
        JoinNonce = packet["PHYPayload"]["JoinAccept"]["JoinNonce"] 
        NetID = packet["PHYPayload"]["JoinAccept"]["Home_NetID"] 
        DevAddr = packet["PHYPayload"]["JoinAccept"]["DevAddr"] 

        # dlsettings
        dlb = packet["PHYPayload"]["JoinAccept"]["DLSettings"]["OptNeg"] 
        dlb = dlb + packet["PHYPayload"]["JoinAccept"]["DLSettings"]["RX1DRoffset"] 
        dlb = dlb + packet["PHYPayload"]["JoinAccept"]["DLSettings"]["RX2Datarate"]
        DLSettings = binascii.hexlify(str.encode(chr(int(dlb, 2)))).decode()

        RxDelay = packet["PHYPayload"]["JoinAccept"]["RxDelay"]
        CFList = packet["PHYPayload"]["JoinAccept"]["CFList"]

        cmacF = cmac.CMAC(algorithms.AES(bytes.fromhex(nkey)), backend=default_backend())
        data = bytes.fromhex(MHDR + JoinNonce + NetID + DevAddr + DLSettings 
            + RxDelay + CFList)
        cmacF.update(data)
        return binascii.hexlify(cmacF.finalize()[:4]).decode()

    # TODO: Implement type 1
    #
    # Spec: LoRaWAN 1.1
    #
    # Type 0/2:
    # cmac = aes128_cmac(SNwkSIntKey, MHDR | RejoinType | NetID | DevEUI | RJcount0)
    # MIC = cmac[0..3]
    #
    # Type 1:
    # cmac = aes128_cmac(JSIntKey, MHDR | RejoinType | JoinEUI| DevEUI | RJcount1)
    # MIC = cmac[0..3]
    #
    # if Rejoin-request
    elif ptype == REJOIN_REQUEST: 
        retype = packet["PHYPayload"]["ReJoinRequest"]["ReJoinType"] 

        # type 0/2
        if int(retype, 16) == 0 or int(retype, 16) == 2: 
            NetID = packet["PHYPayload"]["ReJoinRequest"]["NetID"]
            DevEUI = packet["PHYPayload"]["ReJoinRequest"]["DevEUI"]
            RJcount0 = packet["PHYPayload"]["ReJoinRequest"]["RJcount0"]

            cmacF = cmac.CMAC(algorithms.AES(bytes.fromhex(nkey)), backend=default_backend())
            data = bytes.fromhex(MHDR + retype + NetID + DevEUI + RJcount0)
            cmacF.update(data)
            return binascii.hexlify(cmacF.finalize()[:4]).decode()

        # type 1
        elif int(retype, 16) == 1:
            return ""

        else:
            return "Error: Invalid packet!"

    #
    # Spec: LoRaWAN 1.1
    #
    # Size (bytes):   1        4     1        4        4          1       1
    # B0 block:       0x49  0x0000  Dir(0x00) DevAddr  FCntUp  0x00  len(msg)
    # Size (bytes):   1        2     1      1      1          4       4      1       1
    # B1 block:      0x49  ConfFCnt  TxDr  TxCh  Dir(0x00)  DevAddr  FCntUp  0x00  len(msg)
    #
    # cmacS = aes128_cmac(SNwkSIntKey, B 1 | msg)
    # cmacF = aes128_cmac(FNwkSIntKey, B 0 | msg)
    #
    # LoRaWAN1.0 Network Server: MIC = cmacF[0..3]
    # LoRaWAN1.1 Network Server: MIC = cmacS[0..1] | cmacF[0..1]
    #
    # if Unconfirmed Data Up / Down and Confirmed Data Up / Down
    elif ptype == UP_MSG_CON or ptype == DW_MSG_CON or ptype == UP_MSG_NCON or ptype == DW_MSG_NCON:
        try:
            # uplink messages
            if ptype == UP_MSG_CON or ptype == UP_MSG_NCON: dir_arg = "00" 
            # downlink messages
            else: dir_arg = "01" 

            # msg and msg len
            msg = bytes.fromhex(packet["RAWPacket"][0:len(packet["RAWPacket"])-8])
            msg_len = hex(len(msg)).replace("0x","")
            if len(msg_len)%2 == 1: 
                msg_len = "0" + msg_len

            # from big endian to little endian
            devaddr = "%08x" % struct.unpack("<L", 
                bytes.fromhex(packet["PHYPayload"]["MACPayload"]["FHDR"]["DevAddr"]))[0]
            fcnt = "%04x" % struct.unpack("<H", 
                bytes.fromhex(packet["PHYPayload"]["MACPayload"]["FHDR"]["FCnt"]))[0]

            # b0 block calc
            b0_block = bytes.fromhex("4900000000" + dir_arg + devaddr + fcnt + "0000" + 
                "00" + msg_len)
            
            # LoRaWAN1.0 Network Server: MIC = cmacF[0..3]
            cmacF = cmac.CMAC(algorithms.AES(bytes.fromhex(nkey)), backend=default_backend())
            cmacF.update(b0_block + msg)

            # LoRaWAN1.1 Network Server: MIC = cmacS[0..1] | cmacF[0..1]
            # TODO: MIC for LoRaWAN 1.1 Net Server

            return binascii.hexlify(cmacF.finalize()[:4]).decode()

        except:
            #print(sys.exc_info())
            return ""
    else: 
        return ""

# usage
def usage():
    print("[*]")
    print("[*] FLoRa framework (crypto & mic):")
    print("[*] Usage: ./%s decrypt   [RAW_PACKET] [APP_KEY]" % sys.argv[0])
    print("[*] Usage: ./%s encrypt   [RAW_PACKET] [APP_KEY]" % sys.argv[0])
    print("[*] Usage: ./%s calc-mic  [RAW_PACKET] [NET_KEY]" % sys.argv[0])
    print("[*] Usage: ./%s check-mic [RAW_PACKET] [NET_KEY]" % sys.argv[0])
    print("[*]")
    print("[*] Usage: ./%s calc-keys [JOIN_PACKET] [ACCEPT_PACKET] [APP_KEY]" % sys.argv[0])
    print("[*]")

# This aims to provide the crypto & mic functionalities as a separate tool
if __name__ == '__main__':
    # args len
    args = sys.argv
    if len(args) == 4:
        raw_packet = args[2]
        key = args[3]
        packet = flora_parse_packet.packet_parse(raw_packet)

        # decrypt
        if args[1] == "decrypt":
            print(packet_decrypt(packet, key))

        # encrypt 
        elif args[1] == "encrypt":
            print(packet_encrypt(packet, key))

        # calc-mic
        elif args[1] == "calc-mic":
            print(packet_calculate_mic(packet, key))

        # check-mic
        elif args[1] == "check-mic":
            print(packet_check_mic(packet, key))

        else:
            usage()

    # calc-keys
    elif len(args) == 5 and args[1] == "calc-keys":
        rjr_packet = args[2]
        rja_packet = args[3]
        key = args[4]

        jr_packet = flora_parse_packet.packet_parse(rjr_packet)
        ja_packet = flora_parse_packet.packet_parse(rja_packet)

        print(calculate_keys(jr_packet, ja_packet, key))

    else:
        usage()
