# FLoRa Framework v2.0
import sys, binascii
import json
import string

import datetime

# local imports
import flora_parse_packet
import flora_security

# Packets type
JOIN_REQUEST = "000"
JOIN_ACCEPT = "001"
REJOIN_REQUEST = "110"
UP_MSG_NCON = "010"
DW_MSG_NCON = "011"
UP_MSG_CON = "100"
DW_MSG_CON = "101"
PROPIERATY = "111"

# configuration
path_keys_file = "./common-keys.txt"

# Attack: Looking for same device with same counters (FCnt)
def attack_counter(raw_packet_list):
    list_index_found = []
    packet_list = []

    # retrieving parsed packets from raw (hex)
    for raw_packet in raw_packet_list:
        packet = flora_parse_packet.packet_parse(raw_packet)
        packet_list.append(packet)

    # list of packets
    for index1, packet1 in enumerate(packet_list):
        # only up/dw packets can be affected
        ptype = packet1["PHYPayload"]["MHDR"]["MType"]
        if ptype == UP_MSG_CON or ptype == DW_MSG_CON or \
            ptype == UP_MSG_NCON or ptype == DW_MSG_NCON:

            DevAdd1 = packet1["PHYPayload"]["MACPayload"]["FHDR"]["DevAddr"]
            FCnt1 = packet1["PHYPayload"]["MACPayload"]["FHDR"]["FCnt"]

            for index2, packet2 in enumerate(packet_list): 
                ptype = packet2["PHYPayload"]["MHDR"]["MType"]

                # excluding same packets, "N/A" values and only up/dw packets
                if index1 != index2 and DevAdd1 != "N/A" and FCnt1!= "N/A" and \
                    (ptype == UP_MSG_CON or ptype == DW_MSG_CON or \
                    ptype == UP_MSG_NCON or ptype == DW_MSG_NCON):

                    # same devaddr's and counters?
                    if DevAdd1 == packet2["PHYPayload"]["MACPayload"]["FHDR"]["DevAddr"] \
                        and FCnt1 == packet2["PHYPayload"]["MACPayload"]["FHDR"]["FCnt"]:

                        # packet already included 
                        if index1+1 not in list_index_found: list_index_found.append(index1+1)
                        if index2+1 not in list_index_found: list_index_found.append(index2+1)

    return list_index_found

# Attack: Looking for same nonces (either DevNonce or JoinNonce)
def attack_nonces(raw_packet_list):
    list_index_found = []
    packet_list = []

    # retrieving parsed packets from raw (hex)
    for raw_packet in raw_packet_list:
        packet = flora_parse_packet.packet_parse(raw_packet)
        packet_list.append(packet)

    # list of packets
    for index1, packet1 in enumerate(packet_list):
        ptype = packet1["PHYPayload"]["MHDR"]["MType"]

        # join-request can be affected
        if ptype == JOIN_REQUEST:

            JoinEUI = packet1["PHYPayload"]["JoinRequest"]["JoinEUI"]
            DevNonce = packet1["PHYPayload"]["JoinRequest"]["DevNonce"] 

            for index2, packet2 in enumerate(packet_list): 
                p2type = packet2["PHYPayload"]["MHDR"]["MType"]

                # excluding same packets, "N/A" values and only join-req packets
                if index1 != index2 and JoinEUI != "N/A" and DevNonce != "N/A" and \
                    p2type == JOIN_REQUEST:

                    # same joineui's and devnonces's?
                    if JoinEUI == packet2["PHYPayload"]["JoinRequest"]["JoinEUI"] \
                        and DevNonce == packet2["PHYPayload"]["JoinRequest"]["DevNonce"]:

                        # packet already included 
                        if index1+1 not in list_index_found: list_index_found.append(index1+1)
                        if index2+1 not in list_index_found: list_index_found.append(index2+1)

        # join-request can be affected
        if ptype == JOIN_ACCEPT:

            JoinNonce = packet1["PHYPayload"]["JoinAccept"]["JoinNonce"] 
            NetID = packet1["PHYPayload"]["JoinAccept"]["Home_NetID"]

            for index2, packet2 in enumerate(packet_list): 
                p2type = packet2["PHYPayload"]["MHDR"]["MType"]

                # excluding same packets, "N/A" values and only join-req packets
                if index1 != index2 and JoinNonce != "N/A" and NetID != "N/A" and \
                    p2type == JOIN_ACCEPT:

                    # same joineui's and devnonces's?
                    if JoinNonce == packet2["PHYPayload"]["JoinAccept"]["JoinNonce"] \
                        and NetID == packet2["PHYPayload"]["JoinAccept"]["Home_NetID"]:

                        # packet already included 
                        if index1+1 not in list_index_found: list_index_found.append(index1+1)
                        if index2+1 not in list_index_found: list_index_found.append(index2+1)

        # other packtes
        else: pass

    return list_index_found

# Attack: Brute-forcing network keys
def attack_nkeys(raw_packet_list):
    keys_info_found = ""
    found = 0

    # loop for the common net keys (from 00 to ff and from 00*16 to ff*16)
    keys = open(path_keys_file, "r").readlines()
    for i in range(256): 
        keys.append(bytes([i]).hex()) 
        keys.append(bytes([i]).hex() * 16)
    
    # packets loop
    for index, raw_packet in enumerate(raw_packet_list):
        packet = flora_parse_packet.packet_parse(raw_packet)

        # only valid messages
        if packet["ParseMessage"] == "":

            # keys loop
            for key in keys:
                key = key.replace("\n","")
                key = "0" * (32 - len(key)) + key
               
                resp = flora_security.packet_check_mic(packet, key)

                # valid mic
                if resp == "OK":
                    keys_info_found += "ID: %d - NwkSKey: %s\n" % (index + 1, key)
                    found += 1

    keys_info_found = "%d of %d packets were found with a valid MIC:\n\n" % \
        (found, len(raw_packet_list)) + keys_info_found
    return keys_info_found

# Attack: Brute-forcing application keys
def attack_akeys(raw_packet_list):
    keys_info_found = ""
    found = 0

    # loop for the common net keys (from 00 to ff and from 00*16 to ff*16)
    keys = open(path_keys_file, "r").readlines()
    for i in range(255): 
        keys.append(bytes([i]).hex()) 
        keys.append(bytes([i]).hex() * 16)

    # packets loop
    for index, raw_packet in enumerate(raw_packet_list):
        packet = flora_parse_packet.packet_parse(raw_packet)

        # only valid messages
        if packet["ParseMessage"] == "":

            # keys  loop 
            for key in keys:
                key = key.replace("\n","")
                key = "0" * (32 - len(key)) + key

                # up/dwn packets
                ptype = packet["PHYPayload"]["MHDR"]["MType"]
                if ptype == UP_MSG_CON or ptype == DW_MSG_CON or \
                    ptype == UP_MSG_NCON or ptype == DW_MSG_NCON:

                    decrypted_msg = flora_security.packet_decrypt(packet, key)

                    if decrypted_msg != "":
                        # non-printable text will raise an exception
                        try:
                            printable_text = bytes.fromhex(decrypted_msg).decode()
                            keys_info_found += "ID: %d - AppSKey: %s - " % (index + 1, key) + \
                                "Printable text: %s\n" % repr(printable_text)
                            found += 1
                        except:
                            pass

                # join-accept (decrypt + check the MIC)
                elif ptype == JOIN_ACCEPT:
                    decrypted_pkt = flora_security.packet_decrypt(packet, key)
                    ja_packet = flora_parse_packet.packet_parse(decrypted_pkt)
                    resp = flora_security.packet_check_mic(ja_packet, key)

                    # valid join-accept packet
                    if resp == "OK":
                        keys_info_found += "ID: %d - AppKey: %s - " % (index + 1, key) + \
                            "(Join-Accept pkt)\n" 
                        found += 1

    keys_info_found = "%d packets were found potentially printable:\n\n" % \
        found + keys_info_found
    return keys_info_found

# Attack: Eavesdropping attack
def eavesdropping(cipher1, cipher2, plain1):

    ciphers_xored = ""
    out = ""
    keys = []

    # xoring both cihpertexts
    min_len = min(len(cipher1), len(cipher2))
    for pos in range(min_len):
        ciphers_xored += chr(cipher1[pos] ^ cipher2[pos])    

    # if plain text has not the same size as the ciphers, different positions must be tried
    padding = min_len - len(plain1)
    for pad_index in range(padding + 1):
        plain2 = ""

        # xoring the ciphers with the plaintext
        for pos in range(len(plain1)):
            plain2 += chr( ord(ciphers_xored[pad_index + pos]) ^ ord(plain1[pos]) )

        # is it printable?
        printable = all(c in string.printable for c in plain2)
        if printable == True:
            keys.append("*" * pad_index + plain2 + "*" * (padding - pad_index))

    # out format
    for i, m in enumerate(keys):
        out += "[*] %d) %s\n" % (i, m)

    return out

# Attack: timing attack
def attack_timing(raw_packet_list):
    foo = raw_packet_list[0]
    l = len(raw_packet_list)

    for index, raw_packet in enumerate(raw_packet_list):
        # Counter
        if index < (l - 1):
            next_ = raw_packet_list[index + 1] 

        # Separate from time
        packet_split = raw_packet.split("::")
        packet = flora_parse_packet.packet_parse(packet_split[0])

        # JoinRequest packet
        ptype = packet["PHYPayload"]["MHDR"]["MType"]
        if ptype == JOIN_REQUEST:
            DevEUI = packet["PHYPayload"]["JoinRequest"]["DevEUI"]

            # Ignore milliseconds
            time = packet_split[1].split(":")
            
            #future time....
            five_seconds = int(time[2].split(".")[0]) + 5 
            new_time = time[0] + ":" + time[1] + ":" + str(five_seconds)
            time_compare = new_time.split(":")

            packet_found = helper_find_packet_timings(raw_packet_list, time, time_compare, "JoinAccept")
            #packet_found  is a Join-Accept if found
            
            if packet_found != None:
                # Get time of JoinAccept
                packet_split = packet_found.split("::")
                time = packet_split[1].split(":")
                five_seconds = int(time[2].split(".")[0]) + 5
                new_time = time[0] + ":" + time[1] + ":" + str(five_seconds)
                time_compare = new_time.split(":")

                # looking for Uplink msgs
                packet_found = helper_find_packet_timings(raw_packet_list, time, time_compare, "Uplink")

                if packet_found != None:
                    DevAdd = flora_parse_packet.packet_parse(packet_found)["PHYPayload"]["MACPayload"]["FHDR"]["DevAddr"]
                    print("[*] DevEUI: %s  DevAddr: %s" % (DevEUI, DevAdd))
            else:
                print("[*] ERROR: can't find anything +5sec.")

def helper_find_packet_timings(raw_packet_list, time, time2, type):
    for raw_packet_future in raw_packet_list:
        start_time = datetime.time(int(time[0]), int(time[1]), int(time[2].split(".")[0]))
        end_time = datetime.time(int(time2[0]), int(time2[1]), int(time2[2]))
        packet_split_future = raw_packet_future.split("::")
        time_compare = packet_split_future[1].split(":")
        now_time = datetime.time(int(time_compare[0]), int(time_compare[1]), int(time_compare[2].split(".")[0]))

        if now_time > start_time and now_time <= end_time:
            # Return first found obj
            packet_found = list(filter(lambda x: str(now_time) in x, raw_packet_list))

            for packet in packet_found:
                if type == "JoinAccept":
                    if flora_parse_packet.packet_parse(packet)["PHYPayload"]["MHDR"]["MType"] == JOIN_ACCEPT:
                        return packet_found[0]
                elif type == "Uplink":
                    if (flora_parse_packet.packet_parse(packet)["PHYPayload"]["MHDR"]["MType"] == UP_MSG_CON or \
                        flora_parse_packet.packet_parse(packet)["PHYPayload"]["MHDR"]["MType"] == UP_MSG_NCON) and \
                        flora_parse_packet.packet_parse(packet)["PHYPayload"]["MACPayload"]["FHDR"]["FCnt"] == "0000":
                        return packet_found[0]
    return None


# This aims to provide the parse functionality as a separate tool
if __name__ == '__main__':
    
    args = sys.argv
    if len(args) == 3 and args[1] == "counters":
        raw_packets = args[2].split(",")
        index_list = attack_counter(raw_packets)
        for i in index_list:
            packet = flora_parse_packet.packet_parse(raw_packets[i-1])
            DevAdd = packet["PHYPayload"]["MACPayload"]["FHDR"]["DevAddr"]
            FCnt = packet["PHYPayload"]["MACPayload"]["FHDR"]["FCnt"]
            print("[*] %d) DevAddr: %s FCnt: %s" % (i, DevAdd, FCnt))

    elif len(args) == 3 and args[1] == "nonces":
        raw_packets = args[2].split(",")
        index_list = attack_nonces(raw_packets)
        print(index_list)
        # TODO: print further details about the affected packets such as dev/eui

    elif len(args) == 3 and args[1] == "brute-app":
        raw_packets = args[2].split(",")
        print(attack_akeys(raw_packets))

    elif len(args) == 3 and args[1] == "brute-net":
        raw_packets = args[2].split(",")
        print(attack_nkeys(raw_packets))

    elif len(args) == 5 and args[1] == "eavesdropping":
        cipher1 = bytes.fromhex(args[2])
        cipher2 = bytes.fromhex(args[3])
        plain1 = args[4]
        print("[*] Printable messages:")
        print(eavesdropping(cipher1, cipher2, plain1))

    elif len(args) == 3 and args[1] == "timing":
        raw_packets = args[2].split(",")
        index_list = attack_timing(raw_packets)

    else:
        # usage
        print("[*]")
        print("[*] FLoRa framework (attacks):")
        print("[*]")
        print("[*] Usage:")
        print("[*] ./%s counters [RAW_PACKETS] (separated by commas)" % args[0])
        print("[*] ./%s nonces [RAW_PACKETS] (separated by commas)" % args[0])
        print("[*] ./%s brute-app [RAW_PACKETS] (separated by commas)" % args[0])
        print("[*] ./%s brute-net [RAW_PACKETS] (separated by commas)" % args[0])
        print("[*] ./%s eavesdropping [HEX_CIPHER1] [HEX_CIPHER2] [PLAIN_TEXT_GUESSED]" % args[0])
        print("[*] ./%s timing [RAW_PACKETS]::[TIME] (separated by commas)" % args[0])
        print("[*]")
