# FLoRa Framework v2.0

DEBUG = True

def log(msg):
    if DEBUG: print("[*] %s" % msg)

def receive_packets(sock):

    req, addr = sock.recvfrom(2048)
    req_type = req[3:4]

    """
     Bytes  | Function
    :------:|---------------------------------------------------------------------
     0      | protocol version = 2
     1-2    | random token
     3      | PUSH_DATA identifier 0x00
     4-11   | Gateway unique identifier (MAC address)
     12-end | JSON object, starting with {, ending with }, see section 4
    """
    # PUSH_DATA (token X, GW MAC, JSON payload)
    if req_type == b'\x00':

        log("PUSH_DATA received (%s)" % repr(req))
        """
         Bytes  | Function
        :------:|---------------------------------------------------------------------
         0      | protocol version = 2
         1-2    | same token as the PUSH_DATA packet to acknowledge
         3      | PUSH_ACK identifier 0x01
        """
        # PUSH_ACK (token X)
        msg = b'\x02' +  req[1:3] + b'\x01'
        sock.sendto(msg, addr)
        log("PUSH_ACK sent (%s)" % msg)


    """
     Bytes  | Function
    :------:|---------------------------------------------------------------------
     0      | protocol version = 2
     1-2    | random token
     3      | PULL_DATA identifier 0x02
     4-11   | Gateway unique identifier (MAC address)
    """
    # PULL_DATA (token Y, MAC@)
    if req_type == b'\x02':
        log("PULL_DATA received (%s)" % repr(req))

        """
         Bytes  | Function
        :------:|---------------------------------------------------------------------
         0      | protocol version = 2
         1-2    | same token as the PULL_DATA packet to acknowledge
         3      | PULL_ACK identifier 0x04
        """
        # PULL_ACK (token Y)
        msg = b'\x02' +  req[1:3] + b'\x04'
        sock.sendto(msg , addr)
        log("PULL_ACK sent (%s)" % msg)

        """
         Bytes  | Function
        :------:|---------------------------------------------------------------------
         0      | protocol version = 2
         1-2    | random token
         3      | PULL_RESP identifier 0x03
         4-end  | JSON object, starting with {, ending with }, see section 6
        """
        # PULL_RESP (token Z, JSON payload)
        #sock.sendto("\x02" +  "XX" + "\x03" + "{}", addr)
        #log("PULL_RESP sent")

        """
         Bytes  | Function
        :------:|---------------------------------------------------------------------
         0      | protocol version = 2
         1-2    | same token as the PULL_RESP packet to acknowledge
         3      | TX_ACK identifier 0x05
         4-11   | Gateway unique identifier (MAC address)
         12-end | [optional] JSON object, starting with {, ending with }, see section 6
        """
        # TX_ACK (token Z, JSON payload)
        #tx_req, addr = sock.recvfrom(2048)

        #print(repr(tx_req))
        #tx_req_type = req[3:4]

        #if tx_req_type == "\x05":
        #    log("TX_ACK received")
        #    print("TX JSON: " + tx_req[12:])

    # mac (4-11) and data (12-end)
    mac = req[4:11]
    json_obj = req[12:]

    #import binascii
    #print(binascii.hexlify(req))
    return mac, json_obj
