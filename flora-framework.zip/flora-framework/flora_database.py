# FLoRa Framework v2.0
import sqlite3
import sys

# sqlite table initialization/creation
def sqlite_create(database_path, new_table_name):
    try:
        tables_tb_removed = []
        print("[*] Initializing the database")
        # looking for empty tables 
        con = sqlite3.connect(database_path)
        c = con.cursor()
        tables = c.execute("SELECT name FROM sqlite_master WHERE type='table';")
        for name in tables:
            c = con.cursor()
            c.execute("SELECT count(*) FROM %s;" % name[0])
            num = c.fetchone()[0]
            if num == 0: tables_tb_removed.append(name[0])
        con.close()
        print("[*] %d empty table(s) have been found" % len(tables_tb_removed))

        # removing the empty tables found
        con = sqlite3.connect(database_path)
        for table in tables_tb_removed:
            print("[*] Removing the \"%s\" table" % (table))
            c = con.cursor()
            c.execute("DROP TABLE %s;" % table)
        con.close()

        # creating the new table
        con = sqlite3.connect(database_path)
        c = con.cursor()
        c.execute("CREATE TABLE %s (id integer primary key, \
            packet_parsed text not null)" % new_table_name)
        con.commit()
        con.close()

    except sqlite3.Error as e:
        print(("[!] There was an error creating the table: %s" % e))

# DEBUG
#if __name__ == '__main__':
#    database_path = "lorawan_database.db"
#    sqlite_create(database_path, "lora_sniff_20180528_134125")
