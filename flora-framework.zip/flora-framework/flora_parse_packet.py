# FLoRa Framework v2.0

#
# LoRaWAN-v1.1 version
#
import copy, sys
import json
#import binascii, struct

# Packets type
JOIN_REQUEST = "000"
JOIN_ACCEPT = "001"
REJOIN_REQUEST = "110"
UP_MSG_NCON = "010"
DW_MSG_NCON = "011"
UP_MSG_CON = "100"
DW_MSG_CON = "101"
PROPIERATY = "111"

#MType, Description
mtype= {"000":"Join-Request",
        "001":"Join-Accept",
        "010":"Uplink Msg (UC)",
        "011":"Downlink Msg (UC)",
        "100":"Uplink Msg (C)",
        "101":"Downlink Msg (C)",
        "110":"Rejoin-Request",
        "111":"Proprietary"}

############# LoRaWAN packets structure ini

#
# Spec: LoRaWAN 1.1
#
# packet base
p_payload = {"PHYPayload":{"MHDR": {"MType": "", "RFU":"", "Major":""}}}
# packet mic
p_mic = {"MIC":""}
# lora info
p_lora = {"Lora":{"Freq":"", "Chan":"", "Datr":"", "Codr":""}}
# packet info 
p_type = {"MTypeText":""} 
p_raw_pkt = {"RAWPacket":""} 
p_parse_info = {"ParseMessage":""} 

#
# Spec: LoRaWAN 1.1
#
# uplink / downlink messages 
# Spec: p_base + p_message (uplink/downlink) + p_mic
#
p_message = {"MACPayload":
    {"FHDR":
        {"DevAddr":"",
        "FCnt":"",
        "FOpts":""},
    "FPort":"",
    "FRMPayload":""}}
# Uplink frame (part of p_message)
p_uplink = {"FCtrl": {"ADR":"", "ADRACKReq":"", "ACK":"", "ClassB":"", "FOptsLen":""}}
# Downlink frame (part of p_message)
p_downlink = {"FCtrl": {"ADR":"", "RFU":"", "ACK":"", "FPending":"", "FOptsLen":""}}

#
# Spec: LoRaWAN 1.1
#
# join request 
# Spec: p_base + p_join_req + p_mic
#
p_join_req = {"JoinRequest": 
    {"JoinEUI":"", "DevEUI":"", "DevNonce":""}}

#
# Spec: LoRaWAN 1.1
#
# join accept 
# Spec: p_base + p_join_accept (MIC included)
#
p_join_accept = {"JoinAccept": 
    {"JoinNonce":"", "Home_NetID":"", "DevAddr":"", 
    "DLSettings": {"OptNeg":"", "RX1DRoffset":"", "RX2Datarate":""}, 
    "RxDelay":"", "CFList":""}}

#
# Spec: LoRaWAN 1.1
#
# rejoin request (type 0/2)
# Spec: p_base + p_rejoin_req (t02/t01) + p_mic
#
p_rejoin_req_t02 = {"ReJoinRequest": 
    {"ReJoinType":"", "NetID":"", "DevEUI":"", "RJcount0":""}}
# rejoin request (type 1)
p_rejoin_req_t1 = {"ReJoinRequest": 
     {"ReJoinType":"", "JoinEUI":"", "DevEUI":"", "RJcount1":""}}


############# LoRaWAN packets structure end

# parse LoRaWAN messages (hex format)
def packet_parse(raw):

    # MHDR (type)
    mhdr = "{0:08b}".format(int(raw[:2], 16))
    ptype = mhdr[:3]
    packet = {} 

    # MTypeText + PHYPayload + ParseMessage + RAWPacket + Lora
    base = copy.deepcopy(p_type)
    # PHYPayload
    payload = copy.deepcopy(p_payload)
    base.update(payload)
    # MIC
    mic = copy.deepcopy(p_mic)
    base["PHYPayload"].update(mic)
    # ParseMessage
    parse_info = copy.deepcopy(p_parse_info)
    base.update(parse_info)
    # Lora info
    lora = copy.deepcopy(p_lora)
    base.update(lora)
    # RAWPacket
    raw_pkt = copy.deepcopy(p_parse_info)
    base.update(raw_pkt)

    # if Join-request
    if ptype == JOIN_REQUEST: 
        jr = copy.deepcopy(p_join_req)
        base["PHYPayload"].update(jr)
        packet = parse_join_request(base, raw)

    # if Join-accept
    elif ptype == JOIN_ACCEPT: 
        ja = copy.deepcopy(p_join_accept)
        base["PHYPayload"].update(ja)
        packet = parse_join_accept(base, raw)

    # if Rejoin-request
    elif ptype == REJOIN_REQUEST: 
        # rejoin req type 0/2 or 1
        retype = raw[2:4]
        if int(retype, 16) == 0 or int(retype, 16) == 2:
            rj0 = copy.deepcopy(p_rejoin_req_t02)
            base["PHYPayload"].update(rj0)
        else:
            rj1 = copy.deepcopy(p_rejoin_req_t1)
            base["PHYPayload"].update(rj1)
        packet = parse_rejoin_request(base, raw)

    # if Unconfirmed Data Up / Down and Confirmed Data Up / Down
    elif ptype == UP_MSG_CON or ptype == DW_MSG_CON or ptype == UP_MSG_NCON or ptype == DW_MSG_NCON:
        msg = copy.deepcopy(p_message)
        base["PHYPayload"].update(msg)
        packet = parse_message(base, raw, ptype)

    # if Propietary (111)
    else: 
        packet= {"MTypeText":mtype[ptype]}
        packet["PHYPayload"] = {"MHDR":{"MType":"", "RFU":"", "Major":""}}
        packet["PHYPayload"]["MHDR"]["MType"] = ptype
        packet["PHYPayload"]["MHDR"]["RFU"] = mhdr[3:6]
        packet["PHYPayload"]["MHDR"]["Major"] = mhdr[6:8]
        packet["ParseMessage"] = "Propietary"
        # lora info
        lora= copy.deepcopy(p_lora)
        packet.update(lora)
        packet["RAWPacket"] = raw

        return packet

    # Raw packet
    packet["RAWPacket"] = raw

    # 40 eecdab00 00 d300 0a 699cd92de19182522b91 7cda0f7b (packet example)
    # MHDR (40)
    packet["PHYPayload"]["MHDR"]["MType"] = ptype
    packet["MTypeText"] = mtype[ptype]
    packet["PHYPayload"]["MHDR"]["RFU"] = mhdr[3:6]
    packet["PHYPayload"]["MHDR"]["Major"] = mhdr[6:8]

    # MIC 
    packet["PHYPayload"]["MIC"] = raw[len(raw)-8:]

    return packet

######## Internal parse functions

#
# Size (bytes):     8     8       2
# Join Request:  JoinEUI DevEUI DevNonce
#
# Size: MHDR (1) + 18 bytes + MIC (4)
#
def parse_join_request(packet, raw):
    # size check
    if not len(raw) == 23*2:
        packet["ParseMessage"] = "Corrupted! Invalid packet size."

    packet["PHYPayload"]["JoinRequest"]["JoinEUI"] = raw[2:18]
    #binascii.hexlify(struct.pack("<Q", int(raw[2:18], 16))).decode() 
    packet["PHYPayload"]["JoinRequest"]["DevEUI"] = raw[18:34]
    #binascii.hexlify(struct.pack("<Q", int(raw[18:34], 16))).decode() 
    packet["PHYPayload"]["JoinRequest"]["DevNonce"] = raw[34:38]
    return packet 

#
# Size (bytes):      3       3       4         1          1     (16) Optional   4
# Join Accept:  JoinNonce  NetID  DevAddr  DLSettings  RxDelay      CFList     MIC
#
# Size: MHDR(1) + 16 or 32 bytes 
# Info: The Join Accept payload (including its MIC) is encrypted using the secret AppKey
#
def parse_join_accept(packet, raw):
    # Checking packet size
    if not len(raw) == 17*2 and not len(raw) == 33*2:
        packet["ParseMessage"] = "Corrupted! Invalid packet size."

    packet["PHYPayload"]["JoinAccept"]["JoinNonce"] = raw[2:8]
    packet["PHYPayload"]["JoinAccept"]["Home_NetID"] = raw[8:14]
    packet["PHYPayload"]["JoinAccept"]["DevAddr"] = raw[14:22]
    #binascii.hexlify(struct.pack("<L", int(raw[14:22], 16))).decode() 
    # DLSettings
    dlsettings = "{0:08b}".format(int(raw[22:24], 16))
    packet["PHYPayload"]["JoinAccept"]["DLSettings"]["OptNeg"] = dlsettings[:1]
    packet["PHYPayload"]["JoinAccept"]["DLSettings"]["RX1DRoffset"] = dlsettings[1:4]
    packet["PHYPayload"]["JoinAccept"]["DLSettings"]["RX2Datarate"] = dlsettings[4:8]

    packet["PHYPayload"]["JoinAccept"]["RxDelay"] = raw[24:26]
    # CFList field
    if len(raw) > 17*2: 
        packet["PHYPayload"]["JoinAccept"]["CFList"] = raw[26:58]
    return packet

#
# Size (bytes):   4        1     2    0..15
# FHDR:         DevAddr  FCtrl  FCnt  FOpts
#
# Size (bit):      7    6    5   4        3..0
# FCtrl Downlink:  ADR  RFU  ACK FPending FOptsLen
#
# Size (bit):     7    6         5   4      3..0
# FCtrl Uplink:   ADR  ADRACKReq ACK ClassB FOptsLen
#
# Size: MHDR (1) + 7..22 bytes (FHDR) + 0..1 (FPort) + 0..N (FRMPayload) + MIC (4)
#
def parse_message(packet, raw, ptype):
    # size check (without fopts)
    if not len(raw)-8 >= 8*2 or not len(raw)%2 == 0:
        packet["ParseMessage"] = "Corrupted! Invalid packet size (Small packet)"

    # MACPayload = FHDR + FPort + FRMPayload 
    macpayload = raw[2:len(raw)-8]
    packet["PHYPayload"]["MACPayload"]["FHDR"]["DevAddr"] = macpayload[6:8] + macpayload[4:6] + \
        macpayload[2:4] + macpayload[:2]

    # MACPayload - FHDR - FCtrl (00) 
    fctrl = "{0:08b}".format(int(macpayload[8:10], 16))
    
    # uplink messages
    if ptype == UP_MSG_CON or ptype == UP_MSG_NCON: 

        up = copy.deepcopy(p_uplink)
        packet["PHYPayload"]["MACPayload"]["FHDR"].update(up)

        packet["PHYPayload"]["MACPayload"]["FHDR"]["FCtrl"]["ADR"] = fctrl[:1]
        packet["PHYPayload"]["MACPayload"]["FHDR"]["FCtrl"]["ADRACKReq"] = fctrl[1:2]
        packet["PHYPayload"]["MACPayload"]["FHDR"]["FCtrl"]["ACK"] = fctrl[2:3]  
        packet["PHYPayload"]["MACPayload"]["FHDR"]["FCtrl"]["ClassB"] = fctrl[3:4] 
        packet["PHYPayload"]["MACPayload"]["FHDR"]["FCtrl"]["FOptsLen"] = fctrl[4:8] 

    # downlink messages
    else:
        dw = copy.deepcopy(p_downlink)
        packet["PHYPayload"]["MACPayload"]["FHDR"].update(dw)

        packet["PHYPayload"]["MACPayload"]["FHDR"]["FCtrl"]["ADR"] = fctrl[:1]
        packet["PHYPayload"]["MACPayload"]["FHDR"]["FCtrl"]["RFU"] = fctrl[1:2]
        packet["PHYPayload"]["MACPayload"]["FHDR"]["FCtrl"]["ACK"] = fctrl[2:3]  
        packet["PHYPayload"]["MACPayload"]["FHDR"]["FCtrl"]["FPending"] = fctrl[3:4] 
        packet["PHYPayload"]["MACPayload"]["FHDR"]["FCtrl"]["FOptsLen"] = fctrl[4:8] 

    # MACPayload - FHDR - FCnt (d300) 
    packet["PHYPayload"]["MACPayload"]["FHDR"]["FCnt"] = (macpayload[12:14] + macpayload[10:12])
    # MACPayload - FHDR - Fopts ( if FOptsLen != 0000 ) 
    optslen = int(fctrl[4:8],2)
    if optslen > 0: 
        # size check (are there enough fopts bytes?)
        if not len(macpayload) >= (7*2 + optslen*2):
            packet["ParseMessage"] = "Corrupted! Invalid packet size (Wrong FOpts len)"
        packet["PHYPayload"]["MACPayload"]["FHDR"]["FOpts"] = macpayload[14:14+(optslen*2)]

    # MACPayload 
    # A frame with a valid FHDR, no Fopts (FoptsLen = 0), no Fport and no FRMPayload is a valid frame
    pos = 14 + (optslen * 2)
    if (pos + 2) < len(macpayload):
        packet["PHYPayload"]["MACPayload"]["FPort"] = macpayload[pos:pos+2]
        packet["PHYPayload"]["MACPayload"]["FRMPayload"] = macpayload[pos+2:len(macpayload)] # encrypted
    # FPort without FRMPayload
    elif pos < len(macpayload):
        packet["ParseMessage"] = "Corrupted! Invalid packet size (FPort without FRMPayload)"

    return packet

#
# Size (bytes):      1           3      8       2
# ReJoin Req: ReJoin Type = 0/2 NetID DevEUI RJcount0
#
# Size: MHDR (1) + 14 + MIC (4) = 19
#
# Size (bytes):      1            8      8       2
# ReJoin Req:  ReJoin Type = 1 JoinEUI DevEUI RJcount1
#
# Size: MHDR (1) + 19 + MIC (4) = 24
#
def parse_rejoin_request(packet, raw):
    retype = raw[2:4]
    packet["PHYPayload"]["ReJoinRequest"]["ReJoinType"] = retype 

    # Checking packet size
    if not len(raw) == 19*2 and not len(raw) == 24*2:
        packet["ParseMessage"] = "Corrupted! Invalid packet size."

    # Rejoin type (0 or 2)
    if int(retype, 16) == 0 or int(retype, 16) == 2:
        packet["PHYPayload"]["ReJoinRequest"]["NetID"] = raw[4:10]
        packet["PHYPayload"]["ReJoinRequest"]["DevEUI"] = raw[10:26]
        #binascii.hexlify(struct.pack("<Q", int(raw[10:26], 16))).decode() 
        packet["PHYPayload"]["ReJoinRequest"]["RJcount0"] = raw[26:30]
    # Rejoin type (1)
    elif int(retype, 16) == 1:
        packet["PHYPayload"]["ReJoinRequest"]["JoinEUI"] = raw[4:20]
        #binascii.hexlify(struct.pack("<Q", int(raw[4:20], 16))).decode() 
        packet["PHYPayload"]["ReJoinRequest"]["DevEUI"] = raw[10:36]
        #binascii.hexlify(struct.pack("<Q", int(raw[20:36], 16))).decode() 
        packet["PHYPayload"]["ReJoinRequest"]["RJcount1"] = raw[36:40]
    else:
        packet["ParseMessage"] = "Corrupted! Invalid ReJoinType value."
    return packet


# This aims to provide the parse functionality as a separate tool
if __name__ == '__main__':
    if len(sys.argv) == 2:
        raw = sys.argv[1]
        j = packet_parse(raw)
        print(json.dumps(j, sort_keys=True, indent=2, separators=(',', ': ')))
    else:
        # usage
        print("[*]")
        print("[*] FLoRa framework (packet parser):")
        print("[*] Usage: ./%s [RAW_PACKET]" % sys.argv[0])
        print("[*]")
