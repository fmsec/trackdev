# FLoRa Framework v2.0
# -*- coding: utf-8 -*-
from flask import Flask, render_template, request, Markup
from multiprocessing import Process
import json, time, socket
import sys, datetime
import sqlite3
import json, base64
import binascii
import string
import socket

# TODO:
# - custom packet send functionality should be finished (not working right now)

# ----------------------------- Configuration ------------------------------ #

# Network configuration
wifi_ip = "192.168.1.71"
receiver_port = 1700
web_port = 7000

# web application conf
app = Flask(__name__, template_folder="web/templates", static_folder="web/static/")

# database file name
database_path = "lorawan_database_2_end_devices.db"

# -------------------------------------------------------------------------- #

# local imports
import flora_parse_packet
import flora_attacks
import flora_security
import flora_database
from receivers import flora_receiver_pkt_fwd

# Packets type
JOIN_REQUEST = "000"
JOIN_ACCEPT = "001"
REJOIN_REQUEST = "110"
UP_MSG_NCON = "010"
DW_MSG_NCON = "011"
UP_MSG_CON = "100"
DW_MSG_CON = "101"
PROPIERATY = "111"

# sender vars
sender_ip = ""
sender_port = 0

@app.route('/')
def show_main(reg=""):

    # arguments
    akey = request.args.get('akey')
    nkey = request.args.get('nkey')
    pfilter = request.args.get('pfilter')
    valid = request.args.get('valid')
    attack = request.args.get('attack')

    # arguments validations
    if akey == None: akey = ""
    if nkey == None: nkey = ""
    if pfilter == None: pfilter = ""
    if valid == None: valid = ""
    if valid != "true": valid = ""
    if attack == None: attack = ""

    tables = []
    # retrieving the existing tables from database
    conn = sqlite3.connect(database_path)
    cursor = conn.cursor()
    db_tables = cursor.execute("SELECT name FROM sqlite_master WHERE \
        type='table' order by name DESC;")

    for table in db_tables:
        tables.append(table[0].replace("lora_sniff_",""))

    selected_tables = []
    # the root path was requested
    if reg == "":
        selected_tables.append(tables[0])
        reg = tables[0]

    # all registers were requested
    elif reg == "all":
        selected_tables = tables

    # a specific register was requested
    else:
        selected_tables.append(reg)

    parsed_rows = []
    # getting the content of the tables either one or all of them
    for table_name in selected_tables:
        cursor = conn.cursor()
        rows = cursor.execute("SELECT * FROM lora_sniff_%s" % table_name)

        # creating the rows format for the selected tables
        for row in create_rows_format(rows, akey, nkey, pfilter, valid):
            parsed_rows.append(row)

    # --------------------------- attack helpers --------------------------- #

    # counter attack
    counters_found = [0]
    raw_packet_list = []
    if attack == "counter":
        for row in parsed_rows:
            # row[8] = row["RawPacket"]
            raw_packet_list.append(row[8])

        counters_found = flora_attacks.attack_counter(raw_packet_list)

    # nonces attack
    nonces_found = [0]
    raw_packet_list = []
    if attack == "nonces":
        for row in parsed_rows:
            # row[8] = row["RawPacket"]
            raw_packet_list.append(row[8])

        nonces_found = flora_attacks.attack_nonces(raw_packet_list)

    # brute-force attack (network key)
    elif attack == "n-brute-force":
        for row in parsed_rows:
            # row[8] = row["RawPacket"]
            raw_packet_list.append(row[8])

        return flora_attacks.attack_nkeys(raw_packet_list).replace("\n", "<br>")

    # brute-force attack (application key)
    elif attack == "a-brute-force":
        for row in parsed_rows:
            # row[8] = row["RawPacket"]
            raw_packet_list.append(row[8])

        return flora_attacks.attack_akeys(raw_packet_list).replace("\n", "<br>")

    # -----------------------------------------------------------------------#

    # assigning dynamic data into the template
    template = render_template('sniffer.html', rows=parsed_rows, stable=reg,
        tables=tables, akey=akey, nkey=nkey, pfilter=pfilter, valid=valid,
        counters_found=counters_found, nonces_found=nonces_found)

    conn.close()
    return template

@app.route('/register/<register>')
def show_register(register):
    return show_main(register)

@app.route('/send_packet')
def send_packet(p=""):

    # configuration check
    if sender_ip == "" or sender_port == 0:
        return "Error: Packet sender was not configured!"

    packet = request.args.get('packet')
    if packet == None: packet = p

    is_hex = all(c in string.hexdigits for c in packet)
    if is_hex == True and (len(packet) % 2) == 0 and packet != "":
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(2)
        sock.connect((sender_ip, sender_port))
        try:
            sock.send(packet.encode())
        except:
            return "There was a problem sending the packet! - %s" % str(sys.exc_info())
        sock.close()
        return "Looks like the packet was replayed properly!"

    else:
        return "Wrong HEX format!"

#TODO: This must be recoded and finished.. (not working right now)
@app.route('/send_custom_packet')
def send_custom_packet():
    fpacket = ""
    ppacket = {"RAWPacket":"", "PHYPayload":{"MACPayload":{"FHDR":{"DevAddr":"",
      "FCnt":""}}, "MHDR":{"Mtype":""}}}

    # configuration check
    if sender_ip == "" or sender_port == 0:
        return "Error: Packet sender was not configured!"

    try:
        packet = request.args.get('spacket')
        akey = request.args.get('akey')
        nkey = request.args.get('nkey')
        ptype = request.args.get('type')
        if ptype == "updown":
            counter = request.args.get('fcnt')
            dev_addr = request.args.get('devadd')
            payload = request.args.get('frmpayload')

            # encrypting the payload
            enc_payload = flora_security.packet_decrypt(payload, counter, akey, dev_addr)
            raw_pack = packet + binascii.hexlify(enc_payload)

            # calculating the mic
            ppacket["RAWPacket"] = raw_pack + "TEMP-MIC" # junk

            ppacket["PHYPayload"]["MACPayload"]["FHDR"]["DevAddr"] = dev_addr
            ppacket["PHYPayload"]["MACPayload"]["FHDR"]["FCnt"] = counter
            ppacket["PHYPayload"]["MHDR"]["MType"] = "010"
            mic = flora_security.packet_calculate_mic(ppacket, nkey)
            if enc_payload != "" and mic != "":
                return send_packet(raw_pack + mic)
            else:
                raise Exception("Encryption or MIC are incorrect!")
        else:
            # TODO: The OTAA packets should be implemented
            raise Exception("This type has not been implemented yet!")
    except:
        return "There was a problem parsing the packet! - %s" % str(sys.exc_info())

@app.route('/create_raw_packet')
def create_packet():
    temp = render_template('create.html')
    return temp

# internal web application functions
def create_rows_format(rows, akey, nkey, pfilter, valid):
    formated_rows = []
    temporal_akey = False

    # loop for the existing rows

    for row in rows:
        # row[1] = packet in JSON format
        packet = json.loads(row[1].replace("'","\""))
        ptype = packet["PHYPayload"]["MHDR"]["MType"]
        corrupted = "" if packet["ParseMessage"] == "" else "Y"
        mic = ""

        # lora info
        packet_info = "Freq: " + packet["Lora"]["Freq"] + " | "
        packet_info += "Chan: " + packet["Lora"]["Chan"] + " | "
        packet_info += "Datr: " + packet["Lora"]["Datr"]
        packet_info += Markup(" <br> ")

        # packet filters or valid packets
        if (pfilter == ptype or pfilter == "") and \
            (valid == "" or (valid == "true" and corrupted =="")):

            # index
            index = row[0]

            # this for previous JOIN_ACCEPT packets where a temp akey
            # based on the nkey was assign
            if temporal_akey == True:
                akey = ""
                temporal_akey == False

            # if it is a JOIN_ACCEPT packet, it would be worth to try to use the
            # nkey as akey since JOIN_ACCEPT is encrypted (including MIC)
            if ptype == JOIN_ACCEPT and nkey != "" and akey == "" and corrupted == "":
                temporal_akey = True
                akey = nkey

            # application key applied and not corrupted
            if akey != "" and corrupted == "":
                decrypted_msg = flora_security.packet_decrypt(packet, akey)

                # non-printable text will raise an exception
                try:
                    printable_text = bytes.fromhex(decrypted_msg).decode()
                    if printable_text != "": packet["DecryptedData"] = repr(printable_text)
                except:
                    packet["DecryptedData"] = "Hex: %s" % decrypted_msg

            # network key is applied and not corrupted
            if nkey != "" and corrupted == "":
                resp = flora_security.packet_check_mic(packet, nkey)
                mic = resp

            # Unconfirmed Data Up / Down & Confirmed Data Up / Down
            if ptype == UP_MSG_CON or ptype == DW_MSG_CON or ptype == UP_MSG_NCON or ptype == DW_MSG_NCON:

                # packet_info: dev-addr ; fctrl (ACK) ; fcnt
                packet_info += "DevAddr: " + packet["PHYPayload"]["MACPayload"]["FHDR"]["DevAddr"] + " | "
                packet_info += "ACK: " + packet["PHYPayload"]["MACPayload"]["FHDR"]["FCtrl"]["ACK"] + " | "
                packet_info += "FCnt: " + packet["PHYPayload"]["MACPayload"]["FHDR"]["FCnt"]

                # row format: id, type, time, packet_info, decrypted_msg, corrupted, mic, packet_parsed_dump, raw_packet
                formated_rows.append([
                    index,
                    packet["MTypeText"],
                    packet["Time"],
                    packet_info,
                    packet["DecryptedData"],
                    corrupted,
                    mic,
                    json.dumps(packet, indent=2, sort_keys=True),
                    packet["RAWPacket"]])

            # Join-request
            elif ptype == JOIN_REQUEST:

                # packet_info: app-id (join-eui) ; end-node-id (dev-eui) ; dev-nonce
                packet_info += "JoinEUI: " + packet["PHYPayload"]["JoinRequest"]["JoinEUI"] + " | "
                packet_info += "DevEUI: " + packet["PHYPayload"]["JoinRequest"]["DevEUI"] + " | "
                packet_info += "DevNonce: " + packet["PHYPayload"]["JoinRequest"]["DevNonce"]

                # row format: id, type, time, packet_info, decrypted_msg, corrupted, mic, packet_parsed_dump, raw_packet
                formated_rows.append([
                    index,
                    packet["MTypeText"],
                    packet["Time"],
                    packet_info,
                    "N/A (Join-Requests are not encrypted)",
                    corrupted,
                    mic,
                    json.dumps(packet, indent=2, sort_keys=True),
                    packet["RAWPacket"]])

            # Join-Accept
            elif ptype == JOIN_ACCEPT:

                # Join-Accept packet is encrypted (including the MIC). So if it was
                # decrypted, the MIC should be checked again (with akey) in order
                # to ensure that it was the right key.
                if packet["DecryptedData"] != "":
                    ja_pkt = packet["DecryptedData"].replace("Hex: ", "")
                    decrypted_join_accept_pkt = flora_parse_packet.packet_parse(ja_pkt)
                    resp = flora_security.packet_check_mic(decrypted_join_accept_pkt, akey)
                    mic = resp

                # packet_info: join-nonce ; net-id ; dev-addr
                packet_info += "JoinNonce: " + packet["PHYPayload"]["JoinAccept"]["JoinNonce"] + " | "
                packet_info += "NetID: " + packet["PHYPayload"]["JoinAccept"]["Home_NetID"] + " | "
                packet_info += "DevAddr: " + packet["PHYPayload"]["JoinAccept"]["DevAddr"]

                # row format: id, type, time, packet_info, decrypted_msg, corrupted, mic, packet_parsed_dump, raw_packet
                formated_rows.append([
                    index,
                    packet["MTypeText"],
                    packet["Time"],
                    packet_info,
                    packet["DecryptedData"],
                    corrupted,
                    mic,
                    json.dumps(packet, indent=2, sort_keys=True),
                    packet["RAWPacket"]])

            # ReJoin-Request
            elif ptype == REJOIN_REQUEST:

                retype = packet["PHYPayload"]["ReJoinRequest"]["ReJoinType"]
                # packet_info (type 0/2): type ; net-id ; end-node-eui (dev-eui)
                if int(retype, 16) == 0 or int(retype, 16) == 2:
                    packet_info += "ReJoinType: " + retype + " | "
                    packet_info += "NetID: " + packet["PHYPayload"]["ReJoinRequest"]["NetID"] + " | "
                    packet_info += "DevEUI: " + packet["PHYPayload"]["ReJoinRequest"]["DevEUI"]

                # packet_info (type 1):   type ; app-id (join-eui) ; end-node-id (dev-eui)
                elif int(retype, 16) == 1:
                    packet_info += "ReJoinType: " + retype + " | "
                    packet_info += "JoinEUI: " + packet["PHYPayload"]["ReJoinRequest"]["JoinEUI"] + " | "
                    packet_info += "DevEUI: " + packet["PHYPayload"]["ReJoinRequest"]["DevEUI"]

                # corrupted packet
                else: pass

                # row format: id, type, time, packet_info, decrypted_msg, corrupted, mic, packet_parsed_dump, raw_packet
                formated_rows.append([
                    index,
                    packet["MTypeText"],
                    packet["Time"],
                    packet_info,
                    "N/A (ReJoin-Requests are not encrypted)",
                    corrupted,
                    mic,
                    json.dumps(packet, indent=2, sort_keys=True),
                    packet["RAWPacket"]])

            # Propietary
            else:

                # row format: id, type, time, packet_info, decrypted_msg, corrupted, mic, packet_parsed_dump, raw_packet
                formated_rows.append([
                    index,
                    packet["MTypeText"],
                    packet["Time"],
                    packet_info,
                    "N/A",
                    "",
                    mic,
                    json.dumps(packet, indent=2, sort_keys=True),
                    packet["RAWPacket"]])

    formated_rows.reverse()
    return formated_rows

# main
if __name__ == '__main__':

    print("[*]\n[*] FLoRa framework (web server):\n[*]")

    # read-only mode, just starts the web server with a table selected
    if len(sys.argv) == 3 and sys.argv[1] == "read-only":
        flora_database.sqlite_create(database_path, sys.argv[2])
        app.run(port=web_port)

    # web server and receivers
    elif len(sys.argv) > 1 and sys.argv[1] == "start":

        # extra options
        if len(sys.argv) == 3:
            opts = sys.argv[2].split(":")

            # sender
            if opts[0] == "sender":
                sender_ip = opts[2]
                sender_port = int(opts[3])
                print("[*] Packet sender configured (%s:%s:%d)" % (opts[1], sender_ip, sender_port))

        # new table name
        now = datetime.datetime.now()
        table = "lora_sniff_%s%02d%02d_%02d%02d%02d" % (now.year, now.month, now.day, now.hour, now.minute, now.second)
        # Starting the web server and the sqlite database (thread)
        flora_database.sqlite_create(database_path, table)
        print("[*] Running the web server (thread)")
        web = Process(target=app.run, kwargs=dict(port=web_port))
        web.start()
        time.sleep(2)

        try:
            # Creating an UDP socket server
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.bind((wifi_ip, receiver_port))
            print("[*] The packet forwarder (UDP) parser is started (%s:%d)" % (wifi_ip, receiver_port))

            while True:

                try:
                    # Waiting for a connections
                    mac, json_obj = flora_receiver_pkt_fwd.receive_packets(sock)

                    # valid mac and json data info
                    if mac != b'' and json_obj != b'':
                        pkt_json = json.loads(json_obj)

                        # if packet received contained data
                        if "rxpk" in pkt_json:
                            data = base64.b64decode(pkt_json["rxpk"][0]["data"])
                            packet = flora_parse_packet.packet_parse(binascii.hexlify(data).decode())

                            # addding info related with the packet received
                            packet["Time"] = str(datetime.datetime.now())[:-4]
                            packet["DecryptedData"] = ""
                            # addding LORA info from packet forwarder
                            packet["Lora"]["Freq"] = str(pkt_json["rxpk"][0]["freq"])
                            packet["Lora"]["Chan"] = str(pkt_json["rxpk"][0]["chan"])
                            packet["Lora"]["Codr"] = str(pkt_json["rxpk"][0]["codr"])
                            packet["Lora"]["Datr"] = str(pkt_json["rxpk"][0]["datr"])

                            print("[*] Packet received: %s" % packet)

                            # saving the packet received from the pycom within the database
                            conn = sqlite3.connect(database_path)
                            cursor = conn.cursor()
                            cursor.execute("insert into %s (packet_parsed) values (\"%s\")" % (table, str(packet)))
                            conn.commit()
                            conn.close()
                            print("[*] Packet saved within the database")

                except KeyboardInterrupt:
                    #print("[!] Ctrl-C typed")
                    break

                except:
                    #sock.close()
                    print("[!] %s" % str(sys.exc_info()))
                    print("[!] There was an error with the message received! (wrong packet)")

        except:
            print("[!] %s" % str(sys.exc_info()))
            print("[!] There was an error with packet forwarder parser. (tip: Check your WiFi connection!)")

        finally:
            web.terminate()
            web.join()

    # help
    else:
        print("[*] Usage: ./%s start" % sys.argv[0])
        print("[*] Usage: ./%s read-only [NEW_database_path] (e.g. 20180528_134125)" % sys.argv[0])
        print("[*]")
        print("[*] Extra Options:")
        print("[*] sender:mode:sender_ip:port (Packet sender implementation - Only pycom mode implemented)")
        print("[*]")
        print("[*] Example:")
        print("[*] Usage: ./%s start sender:pycom:192.168.10.30:1701" % sys.argv[0])
        print("[*]")
