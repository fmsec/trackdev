# flora_receiver_869525_freq.py

from network import LoRa
from machine import Pin
from network import WLAN
import binascii, ubinascii
import socket
import time
import machine
import ujson

# led
led = Pin('P9', mode=Pin.OUT, value=1)

## FLoRa Configuration
flora_reciver_port = 1700
wifi_gw = ""

## LoRa Configuration:
_frequency   = 869525000
_tx_power    = 14
_bandwidth   = LoRa.BW_125KHZ
_sf          = 12
_preamble    = 8
_coding_rate = LoRa.CODING_4_5
_power_mode  = LoRa.ALWAYS_ON
_iq = True

# wifi connection
def connect_wifi():
    global wifi_gw
    # reading config
    config_file = "wifi_config.json"
    fo = open(config_file, "r")
    config = ujson.load(fo)

    wifi_gw = config["wifi_gw"]

    wlan = WLAN(mode=WLAN.STA)
    try:
        print("[+] Connecting to the \"%s\" WiFi network.." % config["wifi_ssid"])
        wlan.ifconfig(config=(config["wifi_ip"], config["wifi_mask"], config["wifi_gw"], config["wifi_dns"]))
        wlan.connect(config["wifi_ssid"], auth=(WLAN.WPA2, config["wifi_pass"]))
        while not wlan.isconnected():
            machine.idle()

        print('[+] WLAN connection succeeded!')
        print('[+] IP (%s) address configured!' % config["wifi_ip"])
        print('[+] GW IP: %s' % wifi_gw)

    except Exception as e:
        print("[!] Failed to connect to any known network")

if __name__ == '__main__':
    # WiFi
    connect_wifi()

    # LoRa
    lora = LoRa(mode=LoRa.LORAWAN, frequency=_frequency, tx_power=_tx_power, bandwidth=_bandwidth,
        sf=_sf, preamble=_preamble, coding_rate=_coding_rate, tx_iq=_iq, rx_iq=_iq)

    print("[*] Receiver started (fq:%d sf:%d bw:%d)" % (_frequency, _sf, _bandwidth))

    s = socket.socket(socket.AF_LORA, socket.SOCK_RAW)
    #s.setblocking(False)

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    flora_addr = (wifi_gw, flora_reciver_port)

    led.toggle()

    # change this if you change the LoRa configuration
    pf_pkt = b'\x02\x8c\xc7\x00\xb8\'\xeb\xff\xfe\xac:\xcc{"rxpk":[{"tmst":1640897012,"time":"2020-09-24T09:56:45.046772Z","tmms":1284976624046,"chan":0,"rfch":0,"freq":869.525,"stat":0,"modu":"LORA","datr":"SF12BW125","codr":"4/5","lsnr":-13.5,"rssi":-117,"size":%d,"data":"%s"}]}'

    while True:
        response=s.recv(1024)
        if len(response) > 0:
            led.toggle()
            data = ubinascii.b2a_base64(response).decode().replace("\n","")
            pkt = pf_pkt % (len(data), data)
            sock.sendto(pkt, flora_addr)
            print(flora_addr)
            print("[*] Packet received and sent: %s" % binascii.hexlify(response))
            response = ""
            led.toggle()
