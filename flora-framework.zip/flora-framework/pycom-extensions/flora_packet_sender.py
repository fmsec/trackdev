# flora_packet_sender.py 
# -*- coding: utf-8 -*-

from network import LoRa
from network import WLAN
from machine import Pin
import _thread
import socket
import binascii
import time, machine
import sys, ujson

# led
led = Pin('P9', mode=Pin.OUT, value=1)

## FLoRa Configuration
receiver_port  = 1701
wifi_ip = ""

## Configuration LoRa:
_frequency   = 869525000 
_tx_power    = 14
_bandwidth   = LoRa.BW_125KHZ
_sf          = 12
_preamble    = 8
_coding_rate = LoRa.CODING_4_5
_power_mode  = LoRa.ALWAYS_ON
##

# wifi connection
def connect_wifi():
    # reading config
    config_file = "wifi_config.json"
    fo = open(config_file, "r")
    config = ujson.load(fo)

    wifi_ip = config["wifi_ip"]

    wlan = WLAN(mode=WLAN.STA)
    try:
        print("[+] Connecting to the \"%s\" WiFi network.." % config["wifi_ssid"])
        wlan.ifconfig(config=(config["wifi_ip"], config["wifi_mask"], config["wifi_gw"], config["wifi_dns"]))
        wlan.connect(config["wifi_ssid"], auth=(WLAN.WPA2, config["wifi_pass"]))
        while not wlan.isconnected():
            machine.idle()

        print('[+] WLAN connection succeeded!')
        print('[+] IP (%s) address configured!' % config["wifi_ip"])

    except Exception as e:
        print("[!] Failed to connect to any known network")

# LoRa conf implementation
def lora_configuration(_frequency, _tx_power , _bandwidth, _sf, _preamble, _coding_rate, _power_mode):
    lora = LoRa(mode=LoRa.LORA, frequency=_frequency, tx_power=_tx_power, bandwidth=_bandwidth,
        sf=_sf, preamble=_preamble, coding_rate=_coding_rate, power_mode=_power_mode)

    lora.init(mode=LoRa.LORA, frequency=_frequency, tx_power=_tx_power, bandwidth=_bandwidth,
        sf=_sf, preamble=_preamble, coding_rate=_coding_rate, power_mode=_power_mode,
        tx_iq=True, rx_iq=True)

if __name__ == '__main__':
    # WiFi & LoRa configuration
    connect_wifi()
    lora_configuration(_frequency, _tx_power, _bandwidth, _sf, _preamble, _coding_rate, _power_mode)

    # LoRa socket
    s = socket.socket(socket.AF_LORA, socket.SOCK_RAW)
    s.setblocking(False)

    # TCP socket
    sock = socket.socket(socket.AF_INET,    socket.SOCK_STREAM)
    sock.bind((wifi_ip, receiver_port))
    sock.listen(1)

    print("[+] The LoRaWAN packet sender has been started")
    led.toggle()
    
    # main loop
    while True:
        
        # Waiting for a connection
        conn, caddr = sock.accept()
        print("[+] New connection from: %s" % str(caddr))
        try:
            while True:
                packet = conn.recv(510)
                if len(packet) == 0: 
                    conn.close()
                    break
                    
                if len(packet) < 256:
                    print("[*] Packet received: %s (%d)" % (packet, len(packet)))
                    s.send(binascii.unhexlify(packet))
                    print("[*] Packet sent!")
        except:
            conn.close()
            print("[!] %s" % str(sys.exc_info()))
            print("[!] There was an error with the current connection!")
