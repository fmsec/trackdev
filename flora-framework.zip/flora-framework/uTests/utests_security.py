#
# FLoRa uTests
#
import sys, os

# main imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from flora_security import *
from flora_parse_packet import *

def execute_tests():
    print("[*] == MIC & Crypto tests ==")
    # tests
    jr_tests()
    ja_tests()
    up_tests()
    rjr_tests()
    calc_keys_tests()
    print("[*]")

def compare(d1, d2, test):
    # true
    if d1 == d2:
        print("[*]\033[92m OK\t\033[00m{}".format(test))
    # false
    else:
        print("[*]\033[91m NOK\t\033[00m{}".format(test))

# Join-Request tests
def jr_tests():
    key = "B6B53F4A168A7A88BDF7EA135CE9CFCA"

    # 1) calc-mic
    test = "MIC calculation (join-request)"
    pkt = "00DC0000D07ED5B3701E6FEDF57CEEAF0085CC587FE913"
    out = "587fe913"
    p = packet_parse(pkt)
    o = packet_calculate_mic(p, key)
    compare(out, o, test)

    # 2) check-mic OK
    test = "Right MIC check (join-request)"
    out = "OK"
    o = packet_check_mic(p, key)
    compare(out, o, test)

    # 3) check-mic Fail
    test = "Wrong MIC check (join-request)"
    pkt = "00DC0000D07ED5B3701E6FEDF57CEEAF0085CCAAAAAAAA"
    out = "Fail"
    p = packet_parse(pkt)
    o = packet_check_mic(p, key)
    compare(out, o, test)

# Join-Accept tests
def ja_tests():
    key = "B6B53F4A168A7A88BDF7EA135CE9CFCA"

    # 1) decrypt
    test = "Decrypt (join-accept)"
    pkt = "204DD85AE608B87FC4889970B7D2042C9E72959B0057AED6094B16003DF12DE145"
    out = "203a06e5130000432e01260301184f84e85684b85e84886684586e840055121de0"
    p = packet_parse(pkt)
    o = packet_decrypt(p, key)
    compare(out, o, test)

    # 2) calc-mic
    test = "MIC Calculation (join-accept)"
    pkt = "203a06e5130000432e01260301184f84e85684b85e84886684586e840055121de0"
    out = "55121de0"
    p = packet_parse(pkt)
    o = packet_calculate_mic(p, key)
    compare(out, o, test)
    
    # 3) check-mic OK
    test = "Right MIC Calculation (join-accept)"
    out = "OK"
    o = packet_check_mic(p, key)
    compare(out, o, test)

    # 4) check-mic Fail
    test = "Wrong MIC Calculation (join-accept)"
    pkt = "203a06e5130000432e01260301184f84e85684b85e84886684586e8400BBBBBBBB"
    out = "Fail"
    p = packet_parse(pkt)
    o = packet_check_mic(p, key)
    compare(out, o, test)

# Uplink tests
def up_tests():
    key = "41414141414141414141414141414141"

    # 1) decrypt
    test = "Decrypt (Uplink msg)"
    pkt = "40000000480000000ae033600b9ed38abf06671f92cd46836b13b9de4bbbe04dc0ef3502320bbdc177a452f64ac995e441cae4"
    # This is an unconfirmed LoRaWAN packet!'
    out = "5468697320697320616e20756e636f6e6669726d6564204c6f526157414e207061636b657421"
    p = packet_parse(pkt)
    o = packet_decrypt(p, key)
    compare(out, o, test)

    # 2) calc-mic
    key = "42424242424242424242424242424242"
    test = "MIC Calculation (Uplink msg)"
    out = "e441cae4"
    o = packet_calculate_mic(p, key)
    compare(out, o, test)
    
    # 3) check-mic OK
    test = "Right MIC Calculation (Uplink msg)"
    out = "OK"
    o = packet_check_mic(p, key)
    compare(out, o, test)

    # 4) check-mic Fail
    test = "Wrong MIC Calculation (Uplink msg)"
    pkt = "40000000480000000ae033600b9ed38abf06671f92cd46836b13b9de4bbbe04dc0ef3502320bbdc177a452f64ac995CCCCCCCC"
    out = "Fail"
    p = packet_parse(pkt)
    o = packet_check_mic(p, key)
    compare(out, o, test)

# Keys calculation tests
def calc_keys_tests():
    key = "B6B53F4A168A7A88BDF7EA135CE9CFCA"

    # 1) NwkSKey AppSKey calculation 
    test = "NwkSKey & AppSKey calculation"
    pkt1 = "00DC0000D07ED5B3701E6FEDF57CEEAF0085CC587FE913"
    pkt2 = "203a06e5130000432e01260301184f84e85684b85e84886684586e840055121de0"
    out = "NwkSKey: 2c96f7028184bb0be8aa49275290d4fc\nAppSKey: f3a5c8f0232a38c144029c165865802c"
    p1 = packet_parse(pkt1)
    p2 = packet_parse(pkt2)
    o = calculate_keys(p1, p2, key)
    compare(out, o, test)

# ReJoin-Request tests
def rjr_tests():
    key = "B6B53F4A168A7A88BDF7EA135CE9CFCA"

    # 1) calc-mic
    test = "MIC calculation (join-request)"
    pkt = "00DC0000D07ED5B3701E6FEDF57CEEAF0085CC587FE913"
    out = "587fe913"
    p = packet_parse(pkt)
    o = packet_calculate_mic(p, key)
    compare(out, o, test)

    # 2) check-mic OK
    test = "Right MIC check (join-request)"
    out = "OK"
    o = packet_check_mic(p, key)
    compare(out, o, test)

    # 3) check-mic Fail
    test = "Wrong MIC check (join-request)"
    pkt = "00DC0000D07ED5B3701E6FEDF57CEEAF0085CCAAAAAAAA"
    out = "Fail"
    p = packet_parse(pkt)
    o = packet_check_mic(p, key)
    compare(out, o, test)
