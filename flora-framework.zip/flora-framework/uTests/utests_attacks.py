#
# FLoRa uTests
#
import sys, os

# main imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from flora_attacks import *
import flora_attacks

flora_attacks.path_keys_file = "../common-keys.txt"

def execute_tests():
    print("[*] == Attacks tests ==")
    # tests
    attack1_tests()
    attack2_tests()
    attack3_tests()
    attack4_tests()
    attack5_tests()
    print("[*]")

def compare(d1, d2, test):
    # true
    if d1 == d2:
        print("[*]\033[92m OK\t\033[00m{}".format(test))
    # false
    else:
        print("[*]\033[91m NOK\t\033[00m{}".format(test))

# same counter tests
def attack1_tests():

    test = "Finding same FCnt's test"
    pkts = "400df0adba00170001c016bc2356c5d1f6ef22b940a0543b82364f0ec80bccbb641caa39e34b17,163ac3c7f39f32ae18a4f7d57a3ae67a951a9768e1896a80f6bee7dda5869777e65d459154,00c3f102d07ed5b370c900659f49d5b370bad2503f96a7,40000000480000000ae033600b9ed38abf06671f92cd46836b13b9de4bbbe04dc0ef3502320bbdc177a452f64ac995e441cae4,40000000480000000119aa531161156ea4,400df0adba0017000ac110b63f18cacba4e367b10fbe5a3e822f0e148d08d9f87f18bd97361edc252dd1".split(",")
    out = "[1, 6, 4, 5]"
    o = str(attack_counter(pkts)).replace("\n","")
    compare(out, o, test)

# same nonces tests
def attack2_tests():

    test = "Finding same Nonces test"
    pkts = "00c3f102d07ed5b370c900659f49d5b3704a01f52d67f4,20905ac8c006cc5b0da8f6b071323908012eee8c0e7bf29a8851539277ae4b926c,163ac3c7f39f32ae18a4f7d57a3ae67a951a9768e1896a80f6bee7dda5869777e65d459154,00c3f102d07ed5b370c900659f49d5b370bad2503f96a7,00c3f102d07ed5b370c900659f49d5b3704a01f52d67f4,40000000480000000119aa531161156ea4,400df0adba0017000ac110b63f18cacba4e367b10fbe5a3e822f0e148d08d9f87f18bd97361edc252dd1,20905ac8c006cc5b0da8f6b071323908012eee8c0e7bf29a8851539277ae4b926c".split(",")
    out = "[1, 5, 2, 8]"
    o = str(attack_nonces(pkts)).replace("\n","")
    compare(out, o, test)

# brute nkeys tests
def attack3_tests():

    test = "Brute-forcing NwkSKey's test"
    pkts = "00c3aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,163ac3c7f39f32ae18a4f7d57a3ae67a951a9768e1896a80f6bee7dda5869777e65d459154,00c3f102d07ed5b370c900659f49d5b370bad2503f96a7,40000000480000000ae033600b9ed38abf06671f92cd46836b13b9de4bbbe04dc0ef3502320bbdc177a452f64ac995e441cae4".split(",")
    out = "2 of 4 packets were found with a valid MIC:ID: 3 - NwkSKey: 49879B3108210E9227FA7803F429D329ID: 4 - NwkSKey: 42424242424242424242424242424242"
    o = str(attack_nkeys(pkts)).replace("\n","")
    compare(out, o, test)

# brute akeys tests
def attack4_tests():

    # 1) up messages
    test = "Brute-forcing AppSKey's test (1)"
    pkts = "00c3aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,163ac3c7f39f32ae18a4f7d57a3ae67a951a9768e1896a80f6bee7dda5869777e65d459154,00c3f102d07ed5b370c900659f49d5b370bad2503f96a7,40000000480000000ae033600b9ed38abf06671f92cd46836b13b9de4bbbe04dc0ef3502320bbdc177a452f64ac995e441cae4".split(",")
    out = "1 packets were found potentially printable:ID: 4 - AppSKey: 41414141414141414141414141414141 - Printable text: 'This is an unconfirmed LoRaWAN packet!'"
    o = str(attack_akeys(pkts)).replace("\n","")
    compare(out, o, test)

    # 2) up and ja messages
    test = "Brute-forcing AppSKey's test (2)"
    pkts = "00c3aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,163ac3c7f39f32ae18a4f7d57a3ae67a951a9768e1896a80f6bee7dda5869777e65d459154,00c3f102d07ed5b370c900659f49d5b370bad2503f96a7,40000000480000000ae033600b9ed38abf06671f92cd46836b13b9de4bbbe04dc0ef3502320bbdc177a452f64ac995e441cae4,2030b1c39c3694d76f14f313fb918fdb9c95ed124d4ba1254b186278172bfb3814".split(",")
    out = "2 packets were found potentially printable:ID: 4 - AppSKey: 41414141414141414141414141414141 - Printable text: 'This is an unconfirmed LoRaWAN packet!'ID: 5 - AppKey: 49879B3108210E9227FA7803F429D329 - (Join-Accept pkt)"
    o = str(attack_akeys(pkts)).replace("\n","")
    compare(out, o, test)

# eavesdropping tests
def attack5_tests():

    test = "Eavesdropping test decrypt (1)"
    pkt1 = bytes.fromhex("c110b63f18cacba4e367b10fbe5a3e822f0e148d08d9f87f18bd97361e")
    pkt2 = bytes.fromhex("e60daf294ad3d9f7f130b212a80169ab204d0bbc13c8886318b099274b")
    plain = "is a lorawan test"
    out = "[*] 0) Nn9wru}!s bs6/2Z{************[*] 1) *tj639~<`6t|x{#L|7***********[*] 2) **perx2?}%bjw5w]j0k**********[*] 3) ****;j222;low,6G/7zBo********[*] 4) *****password: HackThe*******"
    o = str(eavesdropping(pkt1, pkt2, plain)).replace("\n","")
    compare(out, o, test)

    # 2) parse wrong join-request
    test = "Eavesdropping test decrypt (2)"
    pkt1 = bytes.fromhex("c110b63f18cacba4e367b10fbe5a3e822f0e148d08d9f87f18bd97361e")
    pkt2 = bytes.fromhex("e60daf294ad3d9f7f130b212a80169ab204d0bbc13c8886318b099274b")
    plain = "this is a lorawan test packet"
    out = "[*] 0) Superpassword: HackThePlanet!"
    o = str(eavesdropping(pkt1, pkt2, plain)).replace("\n","")
    compare(out, o, test)
