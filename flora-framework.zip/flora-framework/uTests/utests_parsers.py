#
# FLoRa uTests
#
import sys, os

# main imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from flora_parse_packet import *

def execute_tests():
    print("[*] == Parsers tests ==")
    # tests
    jr_tests()
    ja_tests()
    up_tests()
    dw_tests()
    rjr_tests()
    others_tests()
    print("[*]")

def compare(d1, d2, test):
    # true
    if d1 == d2:
        print("[*]\033[92m OK\t\033[00m{}".format(test))
    # false
    else:
        print("[*]\033[91m NOK\t\033[00m{}".format(test))

# Join-Request tests
def jr_tests():

    # 1) parse join-request
    test = "Parse Join-request"
    pkt = "00DC0000D07ED5B3701E6FEDF57CEEAF0085CC587FE913"
    out = "{'MTypeText': 'Join-Request', 'PHYPayload': {'MHDR': {'MType': '000', 'RFU': '000', 'Major': '00'}, 'MIC': '587FE913', 'JoinRequest': {'JoinEUI': 'DC0000D07ED5B370', 'DevEUI': '1E6FEDF57CEEAF00', 'DevNonce': '85CC'}}, 'ParseMessage': '', 'Lora': {'Freq': '', 'Chan': '', 'Datr': '', 'Codr': ''}, 'RAWPacket': '00DC0000D07ED5B3701E6FEDF57CEEAF0085CC587FE913'}"
    o = str(packet_parse(pkt))
    compare(out, o, test)

    # 2) parse wrong join-request
    test = "Parse wrong Join-request"
    pkt = "00DC0000D07ED5B3701E6FEDF57CEEAF0085CC587FE913AA"
    out = "{'MTypeText': 'Join-Request', 'PHYPayload': {'MHDR': {'MType': '000', 'RFU': '000', 'Major': '00'}, 'MIC': '7FE913AA', 'JoinRequest': {'JoinEUI': 'DC0000D07ED5B370', 'DevEUI': '1E6FEDF57CEEAF00', 'DevNonce': '85CC'}}, 'ParseMessage': 'Corrupted! Invalid packet size.', 'Lora': {'Freq': '', 'Chan': '', 'Datr': '', 'Codr': ''}, 'RAWPacket': '00DC0000D07ED5B3701E6FEDF57CEEAF0085CC587FE913AA'}"
    o = str(packet_parse(pkt))
    compare(out, o, test)

# Join-Accept tests
def ja_tests():

    # 1) parse join-accept
    test = "Parse Join-accept"
    pkt = "203a06e5130000432e01260301184f84e85684b85e84886684586e840055121de0"
    out = "{'MTypeText': 'Join-Accept', 'PHYPayload': {'MHDR': {'MType': '001', 'RFU': '000', 'Major': '00'}, 'MIC': '55121de0', 'JoinAccept': {'JoinNonce': '3a06e5', 'Home_NetID': '130000', 'DevAddr': '432e0126', 'DLSettings': {'OptNeg': '0', 'RX1DRoffset': '000', 'RX2Datarate': '0011'}, 'RxDelay': '01', 'CFList': '184f84e85684b85e84886684586e8400'}}, 'ParseMessage': '', 'Lora': {'Freq': '', 'Chan': '', 'Datr': '', 'Codr': ''}, 'RAWPacket': '203a06e5130000432e01260301184f84e85684b85e84886684586e840055121de0'}"
    o = str(packet_parse(pkt))
    compare(out, o, test)

    # 2) parse wrong join-accpet
    test = "Parse wrong Join-accept"
    pkt = "203a06e5130000432e01260301184f84e85684b85e84886684586e840055121de0aa"
    out = "{'MTypeText': 'Join-Accept', 'PHYPayload': {'MHDR': {'MType': '001', 'RFU': '000', 'Major': '00'}, 'MIC': '121de0aa', 'JoinAccept': {'JoinNonce': '3a06e5', 'Home_NetID': '130000', 'DevAddr': '432e0126', 'DLSettings': {'OptNeg': '0', 'RX1DRoffset': '000', 'RX2Datarate': '0011'}, 'RxDelay': '01', 'CFList': '184f84e85684b85e84886684586e8400'}}, 'ParseMessage': 'Corrupted! Invalid packet size.', 'Lora': {'Freq': '', 'Chan': '', 'Datr': '', 'Codr': ''}, 'RAWPacket': '203a06e5130000432e01260301184f84e85684b85e84886684586e840055121de0aa'}"
    o = str(packet_parse(pkt))
    compare(out, o, test)
    
# Uplink tests
def up_tests():

    # 1) parse uplink msg
    test = "Parse Uplink msg"
    pkt = "40000000480000000ae033600b9ed38abf06671f92cd46836b13b9de4bbbe04dc0ef3502320bbdc177a452f64ac995e441cae4"
    out = "{'MTypeText': 'Uplink Msg (UC)', 'PHYPayload': {'MHDR': {'MType': '010', 'RFU': '000', 'Major': '00'}, 'MIC': 'e441cae4', 'MACPayload': {'FHDR': {'DevAddr': '48000000', 'FCnt': '0000', 'FOpts': '', 'FCtrl': {'ADR': '0', 'ADRACKReq': '0', 'ACK': '0', 'ClassB': '0', 'FOptsLen': '0000'}}, 'FPort': '0a', 'FRMPayload': 'e033600b9ed38abf06671f92cd46836b13b9de4bbbe04dc0ef3502320bbdc177a452f64ac995'}}, 'ParseMessage': '', 'Lora': {'Freq': '', 'Chan': '', 'Datr': '', 'Codr': ''}, 'RAWPacket': '40000000480000000ae033600b9ed38abf06671f92cd46836b13b9de4bbbe04dc0ef3502320bbdc177a452f64ac995e441cae4'}"
    o = str(packet_parse(pkt))
    compare(out, o, test)

    # 2) parse wrong uplink msg
    test = "Parse wrong Uplink msg (1)"
    pkt = "400000004800aaaaaaaaaaaaaa"
    out = "{'MTypeText': 'Uplink Msg (UC)', 'PHYPayload': {'MHDR': {'MType': '010', 'RFU': '000', 'Major': '00'}, 'MIC': 'aaaaaaaa', 'MACPayload': {'FHDR': {'DevAddr': '48000000', 'FCnt': 'aaaa', 'FOpts': '', 'FCtrl': {'ADR': '0', 'ADRACKReq': '0', 'ACK': '0', 'ClassB': '0', 'FOptsLen': '0000'}}, 'FPort': '', 'FRMPayload': ''}}, 'ParseMessage': 'Corrupted! Invalid packet size (FPort without FRMPayload)', 'Lora': {'Freq': '', 'Chan': '', 'Datr': '', 'Codr': ''}, 'RAWPacket': '400000004800aaaaaaaaaaaaaa'}"
    o = str(packet_parse(pkt))
    compare(out, o, test)

    # 3) parse wrong uplink msg
    test = "Parse wrong Uplink msg (2)"
    pkt = "4000000048ffaaaaaaaaaaaaaa"
    out = "{'MTypeText': 'Uplink Msg (UC)', 'PHYPayload': {'MHDR': {'MType': '010', 'RFU': '000', 'Major': '00'}, 'MIC': 'aaaaaaaa', 'MACPayload': {'FHDR': {'DevAddr': '48000000', 'FCnt': 'aaaa', 'FOpts': 'aa', 'FCtrl': {'ADR': '1', 'ADRACKReq': '1', 'ACK': '1', 'ClassB': '1', 'FOptsLen': '1111'}}, 'FPort': '', 'FRMPayload': ''}}, 'ParseMessage': 'Corrupted! Invalid packet size (Wrong FOpts len)', 'Lora': {'Freq': '', 'Chan': '', 'Datr': '', 'Codr': ''}, 'RAWPacket': '4000000048ffaaaaaaaaaaaaaa'}"
    o = str(packet_parse(pkt))
    compare(out, o, test)

# Downlink tests
def dw_tests():

    # 1) parse downlink msg
    test = "Parse Downlink msg"
    pkt = "63c78a38eaee287c5d123b1264efe659ab297086a48fb95dbbfb32ba42888caefc09eab8e62c5504ed1879531439c960c294343d8c180d802ded6f1a54e353bf2716d4839390e3"
    out = "{'MTypeText': 'Downlink Msg (UC)', 'PHYPayload': {'MHDR': {'MType': '011', 'RFU': '000', 'Major': '11'}, 'MIC': '839390e3', 'MACPayload': {'FHDR': {'DevAddr': 'ea388ac7', 'FCnt': '7c28', 'FOpts': '5d123b1264efe659ab297086a48f', 'FCtrl': {'ADR': '1', 'RFU': '1', 'ACK': '1', 'FPending': '0', 'FOptsLen': '1110'}}, 'FPort': 'b9', 'FRMPayload': '5dbbfb32ba42888caefc09eab8e62c5504ed1879531439c960c294343d8c180d802ded6f1a54e353bf2716d4'}}, 'ParseMessage': '', 'Lora': {'Freq': '', 'Chan': '', 'Datr': '', 'Codr': ''}, 'RAWPacket': '63c78a38eaee287c5d123b1264efe659ab297086a48fb95dbbfb32ba42888caefc09eab8e62c5504ed1879531439c960c294343d8c180d802ded6f1a54e353bf2716d4839390e3'}"
    o = str(packet_parse(pkt))
    compare(out, o, test)

    # 2) parse wrong downlink msg
    test = "Parse wrong Downlink msg"
    pkt = "63c78a38eaee287c5d123b1264e"
    out = "{'MTypeText': 'Downlink Msg (UC)', 'PHYPayload': {'MHDR': {'MType': '011', 'RFU': '000', 'Major': '11'}, 'MIC': '23b1264e', 'MACPayload': {'FHDR': {'DevAddr': 'ea388ac7', 'FCnt': '7c28', 'FOpts': '5d1', 'FCtrl': {'ADR': '1', 'RFU': '1', 'ACK': '1', 'FPending': '0', 'FOptsLen': '1110'}}, 'FPort': '', 'FRMPayload': ''}}, 'ParseMessage': 'Corrupted! Invalid packet size (Wrong FOpts len)', 'Lora': {'Freq': '', 'Chan': '', 'Datr': '', 'Codr': ''}, 'RAWPacket': '63c78a38eaee287c5d123b1264e'}"
    o = str(packet_parse(pkt))
    compare(out, o, test)

# ReJoin-Request tests
def rjr_tests():

    # 1) parse rejoing 
    test = "Parse ReJoin-request"
    pkt = "c400261e1ecf687e208861ce4be544e7b08d21"
    out = "{'MTypeText': 'Rejoin-Request', 'PHYPayload': {'MHDR': {'MType': '110', 'RFU': '001', 'Major': '00'}, 'MIC': 'e7b08d21', 'ReJoinRequest': {'ReJoinType': '00', 'NetID': '261e1e', 'DevEUI': 'cf687e208861ce4b', 'RJcount0': 'e544'}}, 'ParseMessage': '', 'Lora': {'Freq': '', 'Chan': '', 'Datr': '', 'Codr': ''}, 'RAWPacket': 'c400261e1ecf687e208861ce4be544e7b08d21'}"
    o = str(packet_parse(pkt))
    compare(out, o, test)

    # 2) parse wrong rejoing
    test = "Parse wrong ReJoin-request (1)"
    pkt = "c425261e1ecf687e208861ce4be544e7b08d21"
    out = "{'MTypeText': 'Rejoin-Request', 'PHYPayload': {'MHDR': {'MType': '110', 'RFU': '001', 'Major': '00'}, 'MIC': 'e7b08d21', 'ReJoinRequest': {'ReJoinType': '25', 'JoinEUI': '', 'DevEUI': '', 'RJcount1': ''}}, 'ParseMessage': 'Corrupted! Invalid ReJoinType value.', 'Lora': {'Freq': '', 'Chan': '', 'Datr': '', 'Codr': ''}, 'RAWPacket': 'c425261e1ecf687e208861ce4be544e7b08d21'}"
    o = str(packet_parse(pkt))
    compare(out, o, test)

    # 3) parse wrong rejoing
    test = "Parse wrong ReJoin-request (2)"
    pkt = "c425261e1ecf687e208861ce4be544e7b08d21aa"
    out = "{'MTypeText': 'Rejoin-Request', 'PHYPayload': {'MHDR': {'MType': '110', 'RFU': '001', 'Major': '00'}, 'MIC': 'b08d21aa', 'ReJoinRequest': {'ReJoinType': '25', 'JoinEUI': '', 'DevEUI': '', 'RJcount1': ''}}, 'ParseMessage': 'Corrupted! Invalid ReJoinType value.', 'Lora': {'Freq': '', 'Chan': '', 'Datr': '', 'Codr': ''}, 'RAWPacket': 'c425261e1ecf687e208861ce4be544e7b08d21aa'}"
    o = str(packet_parse(pkt))
    compare(out, o, test)

def others_tests():

    # 1) parse propietary
    test = "Parse propietary"
    pkt = "e2ec0fd516e61ebdce5d2fa0a8169b94df1a95c745d2dd45089edefa66"
    out = "{'MTypeText': 'Proprietary', 'PHYPayload': {'MHDR': {'MType': '111', 'RFU': '000', 'Major': '10'}}, 'ParseMessage': 'Propietary', 'Lora': {'Freq': '', 'Chan': '', 'Datr': '', 'Codr': ''}, 'RAWPacket': 'e2ec0fd516e61ebdce5d2fa0a8169b94df1a95c745d2dd45089edefa66'}"
    o = str(packet_parse(pkt))
    compare(out, o, test)
