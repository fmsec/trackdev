# FLoRa Framework v2.0

#
# FLoRa uTests
#
# same folder imports
import utests_security
import utests_parsers
import utests_attacks

# tests
print("[*]\n[*] FLoRa framework uTests:\n[*]")
utests_parsers.execute_tests()
utests_security.execute_tests()
utests_attacks.execute_tests()
