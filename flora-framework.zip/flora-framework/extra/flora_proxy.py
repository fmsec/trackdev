# FLoRa Framework v2.0
import sys, errno
import socket, select
from threading import Thread, Lock
from queue import Queue
import time

# local imports
import flora_fuzzer
import flora_fuzzer_mutators

# global variable
mutator = ""

# TODO:
# - SSL for TCP connections not implemented. Alternatively you can break SSL with socat:
# > socat openssl-listen:443,reuseaddr,cert=[PEM_CERT_PATH],verify=0,fork TCP4:localhost:4444
# > socat TCP-LISTEN:5555,fork,reuseaddr OPENSSL:[TARGET_IP]:443,verify=0
# > openssl req -newkey rsa:2048 -new -nodes -x509 -days 3650 -keyout key.pem -out cert.pem
#
# - Save the packets to be used later with into fuzzer 

client_conn = []
up_pkts = []
up_mutex = Lock()
dw_mutex = Lock()


# UDP response timeout
udp_timeout = 60

# UDP proxy
def udp_proxy(local_ip, local_port, dst_ip, dst_port):
    # variables
    global up_pkts
    global up_mutex
    global dw_mutex

    # socket
    server_s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server_s.bind((local_ip, local_port))
    server_s.setblocking(0)

    dw_pkts = Queue()
    
    # main UDP loop
    while True:

        new = False
        try:
            data, recv_addr = server_s.recvfrom(65535)

            # checking if client connection exists
            if not recv_addr in client_conn:
                client_conn.append(recv_addr) 
                print(f"[*] New connection created from {recv_addr}")
                new = True

            # adding the msg recevied into the UP list
            up_mutex.acquire()
            up_pkts.append((recv_addr, data))
            up_mutex.release()

            # new connection 
            if new == True:
                proxy_thread = Thread(target=thread_udp_proxy, args=(dst_ip, dst_port, recv_addr, dw_pkts))
                proxy_thread.start()

        except socket.error as e:
            if not e.errno in [errno.EAGAIN, errno.EWOULDBLOCK]:
                break

        # checking if DW packets exist
        dw_mutex.acquire()

        for i in range(0, dw_pkts.qsize()):
            msg = dw_pkts.get()
            server_s.sendto(msg[1], msg[0])
            
        dw_mutex.release()

    print("[!] Something wrong happened! exiting..")

# UDP proxy thread
def thread_udp_proxy(dst_ip, dst_port, recv_addr, dw_pkts):
    # variables
    global up_pkts
    global up_mutex
    global mutator

    request = b'' 
    response = b''

    try:

        # creating a connection with the final server
        client_s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        client_s.setblocking(0)
        dst_addr = (dst_ip, dst_port)

        # main thread loop
        while True:

            # new messages from client 
            up_mutex.acquire()

            # checking if there are client msg's for this thread
            i = 0
            while i < len(up_pkts):
                if recv_addr == up_pkts[i][0]:
                
                    up_pkt = up_pkts[i][1]

                    # data mutation
                    if mutator != "" and mutator_mode != "server":
                        base_up_pkt = up_pkt
                        up_pkt = mutate_data(up_pkt)
                        print(f"[*] [UDP:{recv_addr}][cli->serv] Pkt: {repr(base_up_pkt)} | Mut: {repr(up_pkt)}")

                    else:
                        print(f"[*] [UDP:{recv_addr}][cli->serv] Pkt: {repr(up_pkt)}")

                    client_s.sendto(up_pkt, dst_addr)
                    up_pkts.pop(i)
                else: 
                    i += 1

            up_mutex.release()

            # new messages from server
            try:
                response, addr = client_s.recvfrom(65535)
                dw_mutex.acquire()

                # data mutation
                if mutator != "" and mutator_mode != "client":
                    base_response = response
                    response = mutate_data(response)
                    print(f"[*] [UDP:{recv_addr}][srv->cli] Pkt: {repr(base_response)} | Mut: {repr(response)}")

                else:
                    print(f"[*] [UDP:{recv_addr}][srv->cli] Pkt: {repr(response)}")

                dw_pkts.put((recv_addr, response))
                dw_mutex.release()

            except socket.error as e:
                if not e.errno in [errno.EAGAIN, errno.EWOULDBLOCK]:
                    break

        client_s.close()
        print(f"[*] [UDP:{thread_id}] UDP connection {recv_addr} was closed!")

    except:
        print(sys.exc_info())
        print(f"[!] [UDP:{thread_id}] There was an error connecting to {dst_ip}:{dst_port}")


# TCP proxy
def tcp_proxy(local_ip, local_port, dst_ip, dst_port):
    thread_id = 0
    # socket
    server_s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_s.bind((local_ip, local_port))
    server_s.listen(255)
    
    # main TCP loop
    while True:
        conn, addr = server_s.accept()
        print(f"[*] New TCP connection received from {addr} - Thread ID: {thread_id}")
        proxy_thread = Thread(target=thread_tcp_proxy, args=(dst_ip, dst_port, conn, thread_id))
        proxy_thread.start()
        thread_id += 1

# TCP proxy thread
def thread_tcp_proxy(dst_ip, dst_port, server_s, thread_id):
    global mutator
    request = b'' 
    response = b''

    server_s.setblocking(0)

    try:
        # client socket
        client_s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_s.connect((dst_ip, dst_port)) 
        client_s.setblocking(0)

        # main thread loop
        while True:
            
            # data from the server
            try: 
                temp = server_s.recv(4096)
                while temp != "":
                    request += temp
                    temp = server_s.recv(4096)

            except socket.error as e:
                if not e.errno in [errno.EAGAIN, errno.EWOULDBLOCK]:
                    break
            
            # we have received data from client and should be sent to server
            if len(request) > 0: 

                # data mutation
                if mutator != "" and mutator_mode != "server":
                    base_request = request
                    request = mutate_data(request)
                    print(f"[*] [TCP:{thread_id}][cli->srv] Recv: {repr(base_request)} | Mut: {repr(request)}")

                else:
                    print(f"[*] [TCP:{thread_id}][cli->srv] Recv: {repr(request)}")

                # sending data
                client_s.send(request)
                request = b'' 

            # data from the client
            try:
                temp = client_s.recv(4096)
                while temp != "":
                    response += temp
                    temp = client_s.recv(4096)

            except socket.error as e:
                if not e.errno in [errno.EAGAIN, errno.EWOULDBLOCK]:
                    break
            
            # we have received data from server and should be sent to client
            if len(response) > 0: 

                # data mutation
                if mutator != "" and mutator_mode != "client":
                    base_response = response
                    response = mutate_data(response)
                    print(f"[*] [TCP:{thread_id}][srv->cli] Recv: {repr(base_response)} | Mut: {repr(response)}")

                else:
                    print(f"[*] [TCP:{thread_id}][srv->cli] Recv: {repr(response)}")

                # sending data
                server_s.send(response)
                response = b'' 

    except:
        print(sys.exc_info())
        print(f"[!] [TCP:{thread_id}] There was an error connecting to {dst_ip}:{dst_port}")


# data mutation
def mutate_data(data, index=0, max_size=256):
    global mutator
    global mutator_mode
    global lib
    global seed

    # radamsa
    if mutator == "radamsa":
        out = flora_fuzzer_mutators.radamsa_mutation(lib, data, seed+index, max_size)

    # bit flip
    else:
        out = flora_fuzzer_mutators.bit_flip_mutation(data)

    return out 

# help
def help():
    print("[*]")
    print("[*] FLoRa framework (connection proxies)")
    print("[*]")
    print("[*] Usage:")
    print(f"[*] ./{args[0]} tcp [LOCAL_IP:LOCAL_PORT] [DST_IP:DST_PORT] [(radamsa|bit):(client|server|full)]")
    print(f"[*] ./{args[0]} udp [LOCAL_IP:LOCAL_PORT] [DST_IP:DST_PORT] [(radamsa|bit):(client|server|full)]")
    print("[*]")

# main
if __name__ == '__main__':
    args = sys.argv

    try:
        if len(args) > 3:

            # local IP and port
            local = args[2]
            local_ip = local.split(":")[0]
            local_port  = int(local.split(":")[1])

            # destination IP and port
            dst = args[3]
            dst_ip = dst.split(":")[0]
            dst_port  = int(dst.split(":")[1])

            # with mutators
            if len(args) == 5:
                mutator = args[4].split(":")[0].lower() 
                mutator_mode = args[4].split(":")[1].lower() 
                
                if (mutator == "radamsa" or radamsa == "bit") and \
                    (mutator_mode == "client" or mutator_mode == "server" or \
                        mutator_mode == "full"):
                
                    # radamsa initialization
                    lib, seed = flora_fuzzer_mutators.radamsa_init()

                # wrong params
                else:
                    exit(1)

            print("[*] FLoRa proxy executed!")

            # tcp proxy
            if args[1] == "tcp":
                tcp_proxy(local_ip, local_port, dst_ip, dst_port)

            # udp proxy
            elif args[1] == "udp":
                udp_proxy(local_ip, local_port, dst_ip, dst_port)

        # usage
        else:
            help()

    except KeyboardInterrupt:
        #print "[!] Ctrl-C typed"
        pass

    except:
        print(sys.exc_info())
        help()
