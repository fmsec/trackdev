# FLoRa Framework v2.0
from multiprocessing import Process, Lock, Manager, Value
import os, sys, binascii, time
import random
import time
import socket, ssl

# local imports
import flora_fuzzer_tcp
import flora_fuzzer_udp
import flora_fuzzer_mutators

# local modules
from fuzzer_modules import mqtt
from fuzzer_modules import pkt_fwd
"""
from fuzzer_modules import protobuf
from fuzzer_modules import coap
from fuzzer_modules import restapi
from fuzzer_modules import amqp
"""

# TODO:
# - Implement a percetage of packet mutations (e.g from 0 to 10)

PATH_CRASHES="./crashes"

active_threads_mutex = Lock()

def save_packets(packets, module, thread_id, index):
    filename = f"{PATH_CRASHES}/{module}-{thread_id}-{int(time.time())}.crash"
    fo = open(filename, "wb")

    print(f"[!] [T:{thread_id}] Potential crash, autosaving.. (path: {filename})")

    for i in range(len(packets)):
        pkt = packets[(index + i + 1) % len(packets)]
        if pkt != None:
            fo.write(binascii.hexlify(pkt) + b"\n")

    fo.close()

# Main:
# --------------------------------------------------- #

def core_fuzzer(mode, ip, port, module_name, proto, ssl_enabled, cert_path, 
    filename, threads, mutator, interval, reconnect, verbose):

    # shared variables and mutex
    active_threads_mutex = Lock()
    num_packets_sent = Value("i", 0)
    active_threads = Value("i", 0)
    removed_threads_list = Manager().Queue()
    active_threads_list = {}
    crash_detected = Value("i", False)

    raw_packets=[]
    module = ""
    thread_id = 0
    server_socket = ""

    try: 
        """
                    coap: "coap", 
                    restapi: "restapi", 
                    amqp: "amqp",
        """
        # loading function modules 
        modules = { mqtt: "mqtt",
                    pkt_fwd: "pkt_fwd", 
                    globals: "raw"}

        for mod, name in modules.items():
            if name == module_name: module = mod 
        if module == "": raise

        # loading packets from a file
        if filename != "":
            for packet in open(filename, "r"):
                raw_packets.append(bytes.fromhex(packet.replace("\n","")))

        # loading packets from the module
        else:
            raw_packets = module.get_responses()

        # loading mutators variables (radamsa)
        lib, seed = flora_fuzzer_mutators.radamsa_init()

        print("[*] The FLoRa fuzzer has been started!")

        # main loop
        while True:
            
            # exception handler from threads
            if active_threads.value < 0 or crash_detected.value == True: 
                raise KeyboardInterrupt
            else:
                print(f"[-] Packets sent: {num_packets_sent.value} | Active threads: {active_threads.value}\r", end="")

            for i in range(active_threads.value, threads):

                # remove killed/old threads
                for index in range(removed_threads_list.qsize()):
                    del active_threads_list[removed_threads_list.get()]
                    
                target_mode = ""

                # ================================= loading the CLIENT mode
                if mode == "client":

                    # TCP
                    if proto == "TCP":
                        target_mode = flora_fuzzer_tcp.client_mode

                    # UDP
                    elif proto == "UDP":
                        target_mode = flora_fuzzer_udp.client_mode

                    active_threads_mutex.acquire()

                    # threads / sub-process
                    p = Process(target=target_mode, args=((ip, port), raw_packets, module, 
                        proto, ssl_enabled, lib, seed, mutator, thread_id, interval, reconnect, num_packets_sent, 
                        active_threads_mutex, active_threads, removed_threads_list,
                        crash_detected, verbose))

                    active_threads.value += 1
                    active_threads_list[thread_id] = p
                    thread_id += 1
                    p.start()

                    active_threads_mutex.release()

                # ================================= loading the SERVER mode
                elif mode == "server":

                    # TCP
                    if proto == "TCP":
                        # server initialization
                        if server_socket == "":
                            server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                            server_socket.bind((ip, port))
                            server_socket.listen(threads)       

                        conn, addr = server_socket.accept()

                        # ssl enabled
                        if ssl_enabled == True and cert_path != "":
                            context = ssl.SSLContext(ssl.PROTOCOL_TLSv1)
                            context.load_cert_chain(certfile=cert_path)
                            conn = context.wrap_socket(conn, server_side=True)

                        # TCP function
                        target_mode = flora_fuzzer_tcp.server_mode

                    # UDP
                    elif proto == "UDP":
                        conn = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                        conn.bind((ip, port))
                        #conn.setblocking(0)

                        # UDP function
                        target_mode = flora_fuzzer_udp.server_mode

                    active_threads_mutex.acquire()

                    # threads / sub-process
                    p = Process(target=target_mode, args=(conn, raw_packets, lib, seed, module, 
                        proto, mutator, thread_id, interval, num_packets_sent, active_threads_mutex, 
                        active_threads, removed_threads_list, verbose))
                        
                    active_threads.value += 1
                    active_threads_list[thread_id] = p
                    thread_id += 1
                    p.start()

                    active_threads_mutex.release()

            # waiting for new threads
            time.sleep(1)

    except KeyboardInterrupt:
        time.sleep(1)
        #print("Ctrl + C typed..")
        try:
            active_threads_mutex.acquire()
            print("\n[!] Killing all threads")

            for thread, p in active_threads_list.items():
                p.terminate()

            active_threads_mutex.release()
        except:
            print(sys.exc_info())
            print("[!] Error killing all..")

    except:
        print(sys.exc_info())
        print("[!] Error in core_fuzzer()..")
        #sock.close()

# help
def help():
    print("[*]")
    print("[*] FLoRa framework (fuzzer)")
    print("[*]")
    print(f"[*] Usage: ./{sys.argv[0]} [(server|client):ip:port:(udp|tcp)] [module] [extra options]")
    print("[*]")
    print("[*] Modules:")
    print("[*] - mqtt, pkt_fwd, protobuf, coap, restapi, amqp, raw (requires \"fromfile\" option)")
    print("[*]")
    print("[*] Extra Options:")
    print("[*] - verbose:true (Print data sent)")
    print("[*] - fromfile:filepath (Allows to use requests/responses from file (hex format)")
    print("[*] - threads:int (Allows to execute X client threads)")
    print("[*] - mutator:(radamsa|bit) (Mutator selections - radamsa by default")
    print("[*] - interval:int time between packets (0 by default)")
    print("[*] - reconnect:int time used to reconnect (detecting crashes) (3 by default)")
    print("[*] - ssl:(0|1) Use TLS for TCP connections (disabled (0) by default)")
    print("[*] - certpath:filepath (SSL cert path - required for SSL server connections)")
    print("[*]")
    print("[*] Examples:")
    print(f"[*] ./{sys.argv[0]} server:127.0.0.1:4444:tcp mqtt")
    print(f"[*] ./{sys.argv[0]} server:127.0.0.1:4444:tcp mqtt ssl:1")
    print(f"[*] ./{sys.argv[0]} client:127.0.0.1:9999:udp raw fromfile:/tmp/requests.txt")
    print(f"[*] ./{sys.argv[0]} server:127.0.0.1:7777:tcp mqtt fromfile:/tmp/requests.txt")
    print(f"[*] ./{sys.argv[0]} server:127.0.0.1:7777:tcp mqtt fromfile:/tmp/requests.txt threads:20")
    print(f"[*] ./{sys.argv[0]} server:127.0.0.1:7777:tcp mqtt certpath:/tmp/cert.pem verbose:true")
    print("[*]")
  
# main
if __name__ == "__main__":
    args = sys.argv
    extra_options = ["fromfile", "threads", "mutator", "interval", "reconnect", 
        "ssl", "certpath", "verbose"]
    
    try:
        if len(args) > 2:
            # mandatory options (connection)
            mode = args[1].split(":")[0].lower()
            ip = args[1].split(":")[1]
            port = int(args[1].split(":")[2])
            proto = args[1].split(":")[3].upper()

            # mandatory options (module)
            module =  args[2]

            # extra options 
            filename = ""
            mutator = "radamsa"
            threads = 1    
            interval = 0
            reconnect = 3 
            ssl_enabled = False
            cert_path = ""
            verbose = False

            for index in range(3, len(args)): 
                item = args[index].split(":")
                if item[0] in extra_options:

                    if "fromfile" == item[0]: filename = item[1]
                    if "threads" == item[0]: threads = int(item[1])
                    if "mutator" == item[0]: mutator = item[1] 
                    if "interval" == item[0]: interval = float(item[1])
                    if "reconnect" == item[0]: reconnect = float(item[1])
                    if "ssl" == item[0]: 
                        if item[1] == "1": ssl_enabled = True
                    if "certpath" == item[0]: cert_path = item[1]
                    if "verbose" == item[0]:
                        if item[1].lower() == "true": verbose = True

                else:
                    raise Exception("invalid parameters")

            # threads are ignored for UDP server mode
            if proto == "UDP" and mode == "server": threads = 1 

            # checking ssl server conf
            if ssl_enabled == True and mode == "server" and cert_path == "":
                raise Exception("SSL cert path required!")

            # UDP server 
            
            # main function
            core_fuzzer(mode, ip, port, module, proto, ssl_enabled, cert_path, filename, 
                threads, mutator, interval, reconnect, verbose)

        else:
            help()
    except:
        print(sys.exc_info())
        help()
