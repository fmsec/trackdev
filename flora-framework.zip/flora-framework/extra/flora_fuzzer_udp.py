import os, sys, binascii, time
import random
import time
import socket, ssl

# local imports
import flora_fuzzer
import flora_fuzzer_mutators

VERBOSE = False

def print_verbose(data):
    if VERBOSE == True: print("[*] Pkt sent: " + repr(data))

# server mode
# --------------------------------------------------#
def server_mode(sock, responses, lib, seed, module, proto, mutator, thread_id, interval,
    num_packets_sent, active_threads_mutex, active_threads, removed_threads_list, verb):

    # verbose
    global VERBOSE
    VERBOSE = verb

    # 10 packets will be saved
    packets_sent = [None] * 10
    index = 0

    # main loop
    while True:
        try:
            # packets iteration
            for pkt in responses:

                # packet received
                req, addr = sock.recvfrom(65535)

                # module packet process
                packet = module.process_data(pkt, req)

                # mutators
                if mutator == "radamsa":
                    mut_packet = flora_fuzzer_mutators.radamsa_mutation(lib, packet, seed + num_packets_sent.value, 255)
                else:
                    mut_packet = flora_fuzzer_mutators.bit_flip_mutation(packet)

                # sending and saving
                packets_sent[index % len(packets_sent)] = mut_packet

                print_verbose(mut_packet)
                sock.sendto(mut_packet, addr)

                time.sleep(interval)
                num_packets_sent.value += 1
                index += 1

        # ctrl+c
        except KeyboardInterrupt:
            active_threads.value = -1
            break

        except:
            print(sys.exc_info())
            print(f"[!] Error in thread {thread_id}")

            active_threads_mutex.acquire()
            active_threads.value -= 1
            removed_threads_list.put(thread_id)
            active_threads_mutex.release()
            break

# client mode
# --------------------------------------------------- #
def client_mode_connect(conn):
    # connection
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        return sock

    except:
        print(sys.exc_info())
        return ""

def client_mode(conn, requests, module, proto, ssl_enabled, lib, seed, mutator, thread_id, interval, reconnect,
        num_packets_sent, active_threads_mutex, active_threads, removed_threads_list, crash_detected, verb):

    # verbose
    global VERBOSE
    VERBOSE = verb

    # client initialization
    sock = client_mode_connect(conn)
    if sock == "":
       active_threads.value = -1
       if crash_detected.value == False:
          print(f"[!] [T:{thread_id}] It was not possible to start the connection")
       exit(0)

    # 10 packets will be saved
    packets_sent = [None] * 10
    index = 0

    # main loop
    while True:
        try:

            # packets iteration
            for pkt in requests:

                # detecting crashes from other threads
                if crash_detected.value == True:
                    flora_fuzzer.save_packets(packets_sent, "client", thread_id, index)
                    active_threads.value = -1
                    break

                # module packet process
                packet = module.process_data(pkt, "")
                # mutators
                if mutator == "radamsa":
                    mut_packet = flora_fuzzer_mutators.radamsa_mutation(lib, packet, seed + num_packets_sent.value, 255)
                else:
                    mut_packet = flora_fuzzer_mutators.bit_flip_mutation(packet)

                # sending and saving
                packets_sent[index % len(packets_sent)] = mut_packet

                print_verbose(mut_packet)
                sock.sendto(mut_packet, conn)

                time.sleep(interval)
                num_packets_sent.value += 1
                index += 1

        # ctrl+c
        except KeyboardInterrupt:
            active_threads.value = -1
            break

        # sockets errors
        except socket.error as e:
            time.sleep(reconnect)

            # connection check (crash or conn closed?)
            sock = client_mode_connect(conn)
            if sock == "":

                crash_detected.value = True
                # saving the requests
                flora_fuzzer.save_packets(packets_sent, "client", thread_id, index)
                active_threads.value = -1
                break

        # other errors.. we should restart the thread
        except:
            print(sys.exc_info())
            #print(f"[!] Error in thread {thread_id}")

            active_threads_mutex.acquire()
            active_threads.value -= 1
            removed_threads_list.put(thread_id)
            active_threads_mutex.release()
            break
