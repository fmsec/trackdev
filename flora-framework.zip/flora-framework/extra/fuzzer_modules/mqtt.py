# FLoRa Framework v2.0

responses = [ 
    "20020100",                             # 2 connack
    "300c0005746f7069636d657373616765",     # 3 publish
    "320c0005746f7069636d657373616765",     # 3 publish (QoS level)
    "340c0005746f7069636d657373616765",     # 3 publish (DUP flag)
    "40020002",                             # 4 pub-ack
    "50020001",                             # 5 pub-rec
    "62020006",                             # 6 pub-rel
    "70020002",                             # 7 pub-com
    "900400010280",                         # 9 sub-ack
    "a20a00010005746f70696300",             # 10 un-subscription
    "c0004141",                             # 12 ping-request
    "d0004141",                             # 13 ping-response
    ]

requests = [ 
    "104800064d514973647003c6003c00146d6f73717075622f32363437352d6c6170746f70000a77696c6c2d746f706963000c77696c6c2d7061796c6f6164000475736572000470617373",                         # 1 connect
    "820a00010005746f70696300",            # 8 subscription
    "b0020000",                            # 11 un-subscription-ack
    "e0004141",                            # 14 disconnect
    ]

def get_responses():
    out = []
    for resp in responses:
        out.append(bytes.fromhex(resp))

    return out

def get_requests():
    out = []
    for req in requests:
        out.append(bytes.fromhex(req))

    return out

def get_all():
    out = []
    for resp in responses:
        out.append(bytes.fromhex(resp))

    for req in requests:
        out.append(bytes.fromhex(req))

    return out

# protocol logic implementation
def process_data(data, pkt_received):
    return data
