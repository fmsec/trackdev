# FLoRa Framework v2.0

"""
== gw-srv > 3.2 PUSH_DATA packet (0x00)
# Bytes  | Function
# :-----:|---------------------------------------------------------------------
# 0      | protocol version = 2
# 1-2    | random token
# 3      | PUSH_DATA identifier 0x00
# 4-11   | Gateway unique identifier (MAC address)
# 12-end | JSON object {"rxpk":[ {..}, ..], "stat":{..}}

== gw-srv > 5.2. PULL_DATA packet (0x02)
#  Bytes  | Function
# :-----:|---------------------------------------------------------------------
# 0      | protocol version = 2
# 1-2    | random token
# 3      | PULL_DATA identifier 0x02
# 4-11   | Gateway unique identifier (MAC address)

== gw-srv > 5.5 TX_ACK packet (0x05)
# Bytes  | Function
# :-----:|---------------------------------------------------------------------
# 0      | protocol version = 2
# 1-2    | same token as the PULL_RESP packet to acknowledge
# 3      | TX_ACK identifier 0x05
# 4-11   | Gateway unique identifier (MAC address)
# 12-end | [optional] JSON object
"""

# from gateway to server
responses = [ 
    b'\x02\x8c\xc7\x00\xb8\'\xeb\xff\xfe\xac:\xcc{"rxpk":[{"tmst":1640897012,"time":"2020-09-24T09:56:45.046772Z","tmms":1284976624046,"chan":7,"rfch":0,"freq":867.900000,"stat":0,"modu":"LORA","datr":"SF8BW125","codr":"4/8","lsnr":-13.5,"rssi":-117,"size":105,"data":"GnWDXWXsazGo8oVBdGBtxQZRGD5yw4wHObJpf9yIBuhDZ3+43+f/7aDH5kx7sRln5mVndyE3OzGyaLM/oQOuYfJulr33ALkyzVzpmrNbTYzgBrMNM0LUN+fClltWygTKZ0nd7is14qwK"}]}', # PUSH_DATA
    b'\x02\xdb \x00\xb8\'\xeb\xff\xfe\x8a\xc6_{"stat":{"time":"2020-09-24 09:56:43 GMT","lati":40.40551,"long":-3.67525,"alti":628,"rxnb":0,"rxok":0,"rxfw":0,"ackr":100.0,"dwnb":0,"txnb":0}}', # PUSH_DATA (2)
    b'\x02\xb5\xd1\x02\xb8\'\xeb\xff\xfe\x8a\xc6_', # PULL_DATA
    b'\x02\x8c\xc7\x05\xb8\'\xeb\xff\xfe\x8a\xc6_{"txpk_ack":{"error":"COLLISION_PACKET"}}', # TX_ACK
    ]

"""
== srv-gw > 3.3 PUSH_ACK packet (0x01)
# Bytes  | Function
# :-----:|---------------------------------------------------------------------
# 0      | protocol version = 2
# 1-2    | same token as the PUSH_DATA packet to acknowledge
# 3      | PUSH_ACK identifier 0x01

== srv-gw > 5.3. PULL_ACK packet (0x04)
# Bytes  | Function
# :-----:|---------------------------------------------------------------------
# 0      | protocol version = 2
# 1-2    | same token as the PULL_DATA packet to acknowledge
# 3      | PULL_ACK identifier 0x04
    
== srv-gw > 5.4. PULL_RESP packet (0x03)
# Bytes  | Function
# :-----:|---------------------------------------------------------------------
# 0      | protocol version = 2
# 1-2    | random token
# 3      | PULL_RESP identifier 0x03
# 4-end  | JSON object
"""

# from server to gateway
requests = [ 
    b'\x02\xdb \x01', # PUSH_ACK
    b'\x02\xc65\x04', # PULL_ACK
    b'\x02\x8c\xc7\x03{"txpk":{"imme":true,"freq":864.123456,"rfch":0,"powe":14,"modu":"LORA","datr":"SF11BW125","codr":"4/6","ipol":false,"size":32,"data":"H3P3N2i9qc4yt7rK7ldqoeCVJGBybzPY5h1Dd7P7p8v"}}', # PULL_RESP
    ]

def get_responses():
    out = []
    for resp in responses:
        out.append(resp)

    return out

def get_requests():
    out = []
    for req in requests:
        out.append(req)

    return out

def get_all():
    out = []
    for resp in responses:
        out.append(bytes.fromhex(resp))

    for req in requests:
        out.append(bytes.fromhex(req))

    return out

# protocol logic implementation
def process_data(data, pkt_received):

    # TODO: code some protocol logic
    # - random tokens
    # - mac
    # - fuzzing the protocol or the json

    return data
