# FLoRa Framework v2.0
from multiprocessing import Process, Lock, Manager, Value
import os, sys, binascii, time
import random
import time
import ctypes
import socket, ssl

# radamsa should be compiled as library
LIB_RADAMSA_PATH="/usr/lib/libradamsa.so"

# Mutators:
# --------------------------------------------------- #

# radamsa init
def radamsa_init():
    try:
        lib = ctypes.CDLL(LIB_RADAMSA_PATH)
        lib.radamsa.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_uint]
        seed = lib.radamsa_init()
        return lib, seed
    except:
        print("[!] Something was wrong with radamsa initialization")
        print(sys.exc_info())

# radamsa mutation
def radamsa_mutation(lib, data, seed, max_size=256):
    try: 
        out = (ctypes.c_char*max_size)()
        size = lib.radamsa(data, ctypes.c_size_t(len(data)), ctypes.byref(out), ctypes.c_size_t(max_size), seed)
        return out[:size]

    except:
        print("[!] Something was wrong with radamsa mutation")
        print(sys.exc_info())
        return data

# bit flipping mutator (by default: 10% of the packet mutated)
def bit_flip_mutation(data, per=10):
    try:
        data_len = len(data)
        for i in range(int((data_len / per)) + 1):
            index = random.randint(0, data_len - 1)
            ##data = data[:index] + chr(ord(data[index]) ^ (1 << random.randint(0,7))) + data[index+1:]
            data = data[:index] + bytes(chr(data[index] ^ (1 << random.randint(0,7))), "utf-8") + data[index+1:]
        return data
    except:
        print("[!] Something was wrong with bit flip mutator")
        print(sys.exc_info())
        return data
